//
//  HelpVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 15/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit
import WebKit

class HelpVC: UIViewController, WKUIDelegate {

    @IBOutlet var myNaviBar: UINavigationBar!
    var webView: WKWebView!
    
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "도움말"

        let description = "<p> HTML conent <p>"
        var headerString = "<header><meta name='viewport' content='width=100, initial-scale=2.0, maximum-scale=1.0, minimum-scale=1.0'></header>"
        headerString.append(description)
        webView.loadHTMLString("\(headerString)", baseURL: nil)
        
        let myURL = URL(string: ServerWebView)?.appendingPathComponent("help")
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        SetOrientation()
    }
    
}
