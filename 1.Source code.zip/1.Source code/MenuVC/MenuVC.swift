//
//  MenuVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 20/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

enum MenuType: Int {
    case login
    case projectList
    case help
    case about
    case labeling
    case nothing
    case setting
}	

class MenuVC: UITableViewController {

    @IBOutlet var SettingButton: UIButton!
    
    var didTopMenuType: ((MenuType) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let menuType = MenuType(rawValue: indexPath.row) else { return }

        dismiss(animated: true) { [weak self] in
            self?.didTopMenuType?(menuType)
        }
    }
    
    @IBAction func didTapSettingButton(_ sender: Any) {
        guard let menuType = MenuType(rawValue: 6) else { return }
        
        dismiss(animated: true) { [weak self] in
            self?.didTopMenuType?(menuType)
        }
    }
    
    override func viewDidLayoutSubviews() {
        let origin = CGPoint(x: self.view.frame.width - SettingButton.frame.width - 15, y: SettingButton.frame.origin.y)
        let size = CGSize(width: SettingButton.frame.width, height: SettingButton.frame.height)
        SettingButton.frame = CGRect(origin: origin, size: size)
    }
    

}
