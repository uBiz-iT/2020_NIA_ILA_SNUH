//
//  SetServerInfo.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

func SetServerAddress(_ addr:String) {
    
    ServerAddress = addr

//    ServerURL =  String(format: "%@:%d/", ServerAddress, ServerPort)
//    ILA4ML_URL_PROC = ServerURL + "proc"
//    ILA4ML_URL_GETIMAGE = ServerURL + "getImage"
//    ILA4ML_URL_UPLOADIMAGE = ServerURL + "uploadImage"
    
    ServerURL = String(format: "%@", ServerAddress)
    ServerWebView = String(format: "%@", ServerAddress)
    ILA4ML_URL_PROC = URL(fileURLWithPath: ServerURL).appendingPathComponent("proc").absoluteString
    ILA4ML_URL_GETIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("getImage").absoluteString
    ILA4ML_URL_UPLOADIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("uploadImage").absoluteString
    ILA4ML_URL_REMOVEIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("removeImage").absoluteString

    UserDefaults.standard.set(ServerAddress, forKey: DefaultKey_ServerAddress)
    
}

