//
//  CGRect.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension CGRect {
    // ------------------------------------------------------------------------------------
    // 실제 이미지 사이즈에 해당하는 마크 위치 및 크기 계산
    // shape : UIImageView상에서의 위치 및 크기
    // imageOrigin : UIImageView 내부에 설정되어 보여지는 이미지의 상대 원점좌표
    // ratio : 실제이미지 대비 화면상의 이미지 비율
    // ------------------------------------------------------------------------------------
    func transToRealShape(_ imageOrigin:CGPoint, _ ratio:Float) -> CGRect {
        // 계산
        var x = (self.origin.x - imageOrigin.x) / CGFloat(ratio)
        var y = (self.origin.y - imageOrigin.y) / CGFloat(ratio)
        var width = self.width / CGFloat(ratio)
        var height = self.height / CGFloat(ratio)
        
        // 0.5 단위 반올림
        x = round((x * 2)) / 2
        y = round((y * 2)) / 2
        width = round((width * 2)) / 2
        height = round((height * 2)) / 2
        
        return CGRect(x: x, y: y, width: width, height: height)
    }
    
    // ------------------------------------------------------------------------------------
    // 화면 상의 이미지 사이즈에 해당하는 마크 위치 및 크기 계산
    // shape : 실제 이미지 상의 마크 위치 및 크기
    // imageOrigin : UIImageView 내부에 설정되어 보여지는 이미지의 상대 원점좌표
    // ratio : 실제이미지 대비 화면상의 이미지 비율
    // ------------------------------------------------------------------------------------
    func transToViewShape(_ imageOrigin:CGPoint, _ ratio:Float) -> CGRect {
        let x = self.origin.x * CGFloat(ratio) + imageOrigin.x
        let y = self.origin.y * CGFloat(ratio) + imageOrigin.y
        let width = self.width * CGFloat(ratio)
        let height = self.height * CGFloat(ratio)
        
        return CGRect(x: x, y: y, width: width, height: height)
    }
}
