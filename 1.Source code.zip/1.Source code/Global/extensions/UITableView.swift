//
//  UITableView.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020/08/21.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension UITableView {

    func hasRowAtIndexPath(indexPath: NSIndexPath) -> Bool {
        return indexPath.section < self.numberOfSections && indexPath.row < self.numberOfRows(inSection: indexPath.section)
    }
    
}
