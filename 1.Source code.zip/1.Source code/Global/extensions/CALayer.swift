//
//  CALayer.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 11/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension CALayer {
    
    func screenShot(size:CGSize) -> UIImage? {
        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        
        if let context = UIGraphicsGetCurrentContext() {
            self.render(in: context)
            let screenshot = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return screenshot
        }
        return nil
    }
    
    // ------------------------------------------------------------------------------------
    // ShapeLayer를 복사
    // ------------------------------------------------------------------------------------
    func copyLayer<T: CAShapeLayer>() -> T {
        return NSKeyedUnarchiver.unarchiveObject(with: NSKeyedArchiver.archivedData(withRootObject: self)) as! T
    }
    
    // ------------------------------------------------------------------------------------
    // ShapeLayer이동시 애니메이션 안되도록
    // ------------------------------------------------------------------------------------
    class func performWithoutAnimation(_ actionsWithoutAnimation: () -> Void){
        CATransaction.begin()
        CATransaction.setValue(true, forKey: kCATransactionDisableActions)
        actionsWithoutAnimation()
        CATransaction.commit()
    }

    // ------------------------------------------------------------------------------------
    // Layer의 sublayer 갯수
    // ------------------------------------------------------------------------------------
    func sublayersCount() -> Int {
        if let sublayers = self.sublayers {
            return sublayers.count
        }
        else {
            return 0
        }
    }
}
