//
//  UIScrollView.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 11/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit



