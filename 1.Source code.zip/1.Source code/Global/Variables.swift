//
//  Variables.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 30/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

// -----------------------------------------------------------------------
// 서버 접속 정보 관련 변수 선언
// -----------------------------------------------------------------------
var ServerAddress = ""      
//var ServerAddress = "http://"         
var ServerPort = 3011
var ServerWebViewPort = 3011

var ServerURL = String(format: "%@", ServerAddress)                             
var ServerWebView = String(format: "%@", ServerAddress)                         
var ILA4ML_URL_PROC = URL(fileURLWithPath: ServerURL).appendingPathComponent("proc").absoluteString                   
var ILA4ML_URL_GETIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("getImage").absoluteString           
var ILA4ML_URL_UPLOADIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("uploadImage").absoluteString     
var ILA4ML_URL_REMOVEIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("removeImage").absoluteString     

//var ServerURL = String(format: "%@:%d/", ServerAddress, ServerPort)             
//var ServerWebView = String(format: "%@:%d/", ServerAddress, ServerWebViewPort)  
//var ILA4ML_URL_PROC = ServerURL + "proc"                                        
//var ILA4ML_URL_GETIMAGE = ServerURL + "getImage"                                
//var ILA4ML_URL_UPLOADIMAGE = ServerURL + "uploadImage"                          
//var ILA4ML_URL_REMOVEIMAGE = ServerURL + "removeImage"                          

// -----------------------------------------------------------------------
// 서버 요청 관련 변수 선언
// -----------------------------------------------------------------------
var LastURLErrorMessage:String = "No Error"                                     // 서버로 요청한 후의 마지막 에러 메시지 저장
var ResponseErrorCode = 0                                                       // 실패일 경우 에러 코드
let RequestTimeout = 100                                                        // 서버 요청 후 최대 응답시간, 0.1초단위(요청 함수 콜하는 곳)
let RequestURLTimeout = 50                                                      // 서버 요청 후 최대 응답시간, 0.1초단위(실제 요청함수 내에서)

// -----------------------------------------------------------------------
// 앱이 최초 실행되었는지 체크용
// -----------------------------------------------------------------------
var FirstDidBecomeActive = true


// -----------------------------------------------------------------------
// login 정보 글로벌 정의
// -----------------------------------------------------------------------
var isLogin = false;
var LoginID = ""
var LoginName = ""

// -----------------------------------------------------------------------
// project 정보 글로벌 정의
// -----------------------------------------------------------------------
var isWorking = false;
var WorkingProjectCode = ""
var WorkingProjectName = ""
var WorkingProjectImageDir = ""                 // 20200826
var WorkingProjectMulti = "N"
var WorkingProjectMark = "N"
var WorkingLabelingOrder = 0
var WorkingImageIndex = 0
var WorkingImageId = ""                         // 풀스캔 모드 마지막 조회
var WorkingSubImageIndex = 0                    // 20200820
var WorkingSubImageId = ""                      // 20200820
var WorkingImageIdOnReviewMode = ""             // 리뷰 모드 마지막 조회
var LastLabelingImageId = ""
var LastLabelingSubImageId = ""                 // 20200819

// -----------------------------------------------------------------------
// 어느 화면에서 어떤 동작을 한 후 unwind되었는지 확인용
// -----------------------------------------------------------------------
var isNewLogined = false
var isFromLoginMenu = false
var isNewProjectBegan = false
var isFromProjectMenu = false
var isFromSettingMenu = false

// -----------------------------------------------------------------------
// 라벨링 검토 모드
// -----------------------------------------------------------------------
var IsReviewMode = false                // 리뷰 모드인지
var LeftIndexOnReviewMode = -1          // 리뷰 모드시 좌측 라벨 값
var RightIndexOnReviewMode = -1         // 리뷰 모드시 우측 라벨 값
var IncludeLabelingDoneImage = true    // 라벨링 완료한 이미지도 탐색할 것인지
var IsSettingValueChanged = false       // setting치에서 무엇인가 변경이 되었는지...

