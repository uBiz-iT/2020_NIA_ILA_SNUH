//
//  ProjectInfo.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

var ProjectList:[ProjectInfo] = [ProjectInfo]()

class ProjectInfo {
    var code:String?                    // 프로젝트 코드
    var name:String?                    // 프로젝트 명
    var labeling_times:Int?             // 라벨링 차수
    var image_dir:String?               // 이미지 위치
    var labeling_ord:Int?               // 최종(진행중) 라벨링 차수
    var begin_dt:String?                // 라벨링 시작 일자
    var end_dt:String?                  // 라벨링 종료 일자
    var total_num:Int?                  // 전체 대상 개수
    var complete_num:Int?              // 완료 개수
    var working:Bool?                   // 작업중 여부
    var last_image_id:String?         // 마지막 저장된 이미지 id
    var cur_image_id:String?          // 마지막 조회된 이미지 id
    var multi_yn: String?               // 멀티:Y, 싱글:N
    var mark_yn: String?               // 마크대상:Y, 마크비대상:N
}
