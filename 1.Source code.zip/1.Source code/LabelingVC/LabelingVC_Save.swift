//
//  LabelingVC_Save.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 03/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // --------------------------------------------------------------------------------------
    // save 버튼이 클릭되었을때 라벨링 결과와 마킹된 마크 이미지들을 저장
    // --------------------------------------------------------------------------------------
    func saveLabelingResultAndMark() {
        
        ScrollImage.zoomScale = 1.0             // 20200901

        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)

        DoEvents(f:0.01)        // 20200827
        
        if (saveLabelingResult()) {
            
            // 20200819 전체 작업 모드이면 메인 결과에 저장하고 그렇지 않으면 SUB 이미지 결과에 저장
            if (WorkingProjectMulti == "Y") {
                if (wholeSwitch.isOn) {
                    setLabelingResultInfo()
                }
                else {
                    setSubImageLabelingResultInfo() // 20200819 추가
                }
            }
            else {
                setLabelingResultInfo()
            }
            
            setProgressValue()
            
            let imageId = imageArray[currentImageIndex].id!
            
            if (markUpdated) {
                saveMarkedImageInScrollImage(scrollView: ScrollImage, imageView: EditingImage, imageId: imageId)
            }
            
            // 마지막에 저장했던 이미지를 유저디폴트에 저장
            UserDefaults.standard.set(imageId, forKey: DefaultKey_LastLabelingImageId)
            LastLabelingImageId = imageId
            
            // 20200820
            if (WorkingProjectMulti == "Y" && selectedSubImageRowNum >= 0) {
                if let subImageId = subImageArray[selectedSubImageRowNum].sub_image_id {
                    UserDefaults.standard.set(subImageId, forKey: DefaultKey_LastLabelingSubImageId)
                    LastLabelingSubImageId = subImageId
                }
            }

            self.view.showToast(toastMessage: " 저장 완료...  ", duration: 0.3)
            
            // 20200819  저장 후 바로 다음 이미지를 가져옴.
            if (WorkingProjectMulti == "Y") {
                if (wholeSwitch.isOn) {         // 전체 작업 모드이면
                    arrowRightClick()
                }
                else {                          // 개별 이미지 작업 모드이면
                    if ((selectedSubImageRowNum + 1) <= subImageArray.count - 1) {
                        arrowSubImageRightClick()
                    }
                }
            }
            else {
                arrowRightClick()
            }
            
        }
        else {
            if (LastURLErrorMessage != "") {
                let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
                let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                    //self.dismiss(animated: true, completion: nil)
                    alertProgressNoAction.dismiss(animated: true, completion: nil)
                })
                alertProgressNoAction.addAction(otherAction)
                self.present(alertProgressNoAction, animated: false, completion: nil)
            }
        }
        
        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
        
    }
    
    // --------------------------------------------------------------------------------------
    // 라벨링 여부 및 결과를 해당 변수에 저장
    // --------------------------------------------------------------------------------------
    func setLabelingResultInfo() {

        setLabelingResultInfo(image:imageArray[currentImageIndex])
        
//        imageArray[currentImageIndex].isLabelingDone = true
//        imageArray[currentImageIndex].labelingResult.removeAll()
//
//        var labelingLocationResult = LabelingLocationResult()
//        labelingLocationResult.target_cd = 0;
//        labelingLocationResult.label_cd = getLastSelectedIndex(0);
//        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
//
//        labelingLocationResult = LabelingLocationResult()
//        labelingLocationResult.target_cd = 1;
//        labelingLocationResult.label_cd = getLastSelectedIndex(1);
//        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
        
        // 20200819 개별 sub 이미지에 모두 저장
        if subImageArray.count > 0 {
            for image in subImageArray {
                setSubImageLabelingResultInfo(image:image)
            }
            collectionViewThumbnail.reloadData()
        }
    }
    
    // --------------------------------------------------------------------------------------
    // 라벨링 여부 및 결과를 해당 변수에 저장
    // --------------------------------------------------------------------------------------
    func setLabelingResultInfo(image:ImageInfo) {
        
        image.isLabelingDone = true
        image.labelingResult.removeAll()
        
        var labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 0;
        labelingLocationResult.label_cd = getLastSelectedIndex(0);
        image.labelingResult.append(labelingLocationResult);
        
        labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 1;
        labelingLocationResult.label_cd = getLastSelectedIndex(1);
        image.labelingResult.append(labelingLocationResult);
        
    }
    
    // --------------------------------------------------------------------------------------
    // 라벨링 여부 및 결과를 해당 변수에 저장(sub 이미지에 대한 라벨링) 20200819
    // --------------------------------------------------------------------------------------
    func setSubImageLabelingResultInfo() {

        setSubImageLabelingResultInfo(image:subImageArray[selectedSubImageRowNum])
        
        // SUB 이미지 전부를 완료하였으면 전체 라벨링 결과에도 완료했다고 저장 20200820
        let subImageCount = subImageList.count
        let subImageDoneCount = subImageList.doneImages().count

        if subImageCount == subImageDoneCount {
            
            let image = imageArray[currentImageIndex]
            image.isLabelingDone = true
            image.labelingResult.removeAll()
            
            // reject 수량이 0이면 accept(0)으로 처리, 그렇지 않으면 reject(1) 처리
            var rejectCount = subImageList.countByLabel(target_cd: 0, label_cd: 1)

            var labelingLocationResult = LabelingLocationResult()
            labelingLocationResult.target_cd = 0;
            labelingLocationResult.label_cd = (rejectCount == 0) ? 0 : 1
            image.labelingResult.append(labelingLocationResult);
            
            rejectCount = subImageList.countByLabel(target_cd: 1, label_cd: 1)

            labelingLocationResult = LabelingLocationResult()
            labelingLocationResult.target_cd = 1;
            labelingLocationResult.label_cd = (rejectCount == 0) ? 0 : 1
            image.labelingResult.append(labelingLocationResult);
            
        }
    }
    
    // --------------------------------------------------------------------------------------
    // 라벨링 여부 및 결과를 해당 변수에 저장(sub 이미지에 대한 라벨링) 20200819
    // --------------------------------------------------------------------------------------
    func setSubImageLabelingResultInfo(image:SubImageInfo) {
        image.isLabelingDone = true
        image.labelingResult.removeAll()
        
        var labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 0;
        labelingLocationResult.label_cd = getLastSelectedIndex(0);
        image.labelingResult.append(labelingLocationResult);
        
        labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 1;
        labelingLocationResult.label_cd = getLastSelectedIndex(1);
        image.labelingResult.append(labelingLocationResult);
    }
    
    func setLabelingResultInfoByDrop(isDrop:Bool) {
        
        imageArray[currentImageIndex].isLabelingDone = false
        imageArray[currentImageIndex].isDrop = isDrop ? "Y" : "N"
        imageArray[currentImageIndex].labelingResult.removeAll()
        
        var labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 0;
        labelingLocationResult.label_cd = -1;
        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
        
        labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 1;
        labelingLocationResult.label_cd = -1;
        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
        
    }
    
    // --------------------------------------------------------------------------------------
    // 스크롤이미지 안에 마킹된 마크들을 파일로 저장하고 upload해야 함
    // --------------------------------------------------------------------------------------
    func saveMarkedImageInScrollImage(scrollView:UIScrollView, imageView:UIImageView, imageId:String) {
        
//        let beforeZoomScale = scrollView.zoomScale
//        let beforeContentOffset = scrollView.contentOffset
        scrollView.zoomScale = 1.0
        
        saveMarkedImage(imageView:imageView, imageId: imageId)
        
        // 원래의 zoom 크기와 offset으로 원복
//        scrollView.zoomScale = beforeZoomScale
//        scrollView.contentOffset = beforeContentOffset
        
    }
    

}
