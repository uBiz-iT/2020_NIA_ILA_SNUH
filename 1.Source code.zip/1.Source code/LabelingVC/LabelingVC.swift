//
//  LabelingVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020. 08. 10..
//  Copyright © 2020년 uBiz Information Technology. All rights reserved.
//

import UIKit


class LabelingVC: UIViewController, UIScrollViewDelegate {

    @IBOutlet var imageRegionView: UIView!
    @IBOutlet var orgImageRegionView: UIView!                   // 20200814
    @IBOutlet var regionView: UIView!                           // 20200814
    @IBOutlet var regionSplitView: UIView!                      // 20200814
    
    var befErasingPoint:CGPoint?
    var befFreeCurvePoint:CGPoint?
    var imageArray:[ImageInfo] = [ImageInfo]()
    
    var selectedMainImageCellIndexPath:IndexPath?
    var selectedThumbnailCellIndexPath:IndexPath?

    // ---------------------------------------------
    // 제스처 변수 선언
    // ---------------------------------------------
    var longPressGesture:UILongPressGestureRecognizer?          // 다각형에서 컨트롤포인트 삭제 또는 다각형 그리기 완료시 사용
    var tapGesture:UITapGestureRecognizer?                      // 타원을 그릴때와 종료할때 사용
    var doubleTapGesture:UITapGestureRecognizer?                // 참조 이미지 프로그램을 띄울때 사용
    var doubleTapGestureForOrgImage:UITapGestureRecognizer?     // 20200822 원본 이미지 맨처음, 맨 마지막 이미지로 이동하는 용도
    var panGesture:UIPanGestureRecognizer?                      // 자유선, 닫힌자유선을 그리거나 지우개 모드에서 사용, 타원,다각형의 모양, 위치 변경을 위해서 사용
    var longPressGestureForNodelayPan:UILongPressGestureRecognizer?  // pan 제스처가 지연되는 현상이 발생하므로 대신에 짧은 long press로 대신함
    var tapGesture2:UITapGestureRecognizer?                     // 2 터치 탭, 이미지 원래 크기로 돌릴 때 사용
    var tapGesture2Org:UITapGestureRecognizer?                     // 2 터치 탭, 이미지 원래 크기로 돌릴 때 사용

    var compareLineGesture:UILongPressGestureRecognizer?        // 20200924 이미지 비교 가이드 라인 제어용
    var compareLineGestureImage:UILongPressGestureRecognizer?        // 20200924 이미지 비교 가이드 라인 제어용
    var compareLineGestureOrg:UILongPressGestureRecognizer?     // 20200924 이미지 비교 가이드 라인 제어용

    // 20200902
    var swipeLeftGesture:UISwipeGestureRecognizer?              // 마킹 모드가 아닌 경우에는 swipe 가능하게 하기 위하여.
    var swipeRightGesture:UISwipeGestureRecognizer?
    var swipeLeftGestureOrg:UISwipeGestureRecognizer?              // 마킹 모드가 아닌 경우에는 swipe 가능하게 하기 위하여.
    var swipeRightGestureOrg:UISwipeGestureRecognizer?
    // ---------------------------------------------

    var noticeClearMark = false
    
    var autoUpload = UploadThread()
    var canvas = Canvas()

    var lineType:LineType = LineType.FreeCurve
    var lineColor:UIColor = UIColor.red
    var controlPointColor:UIColor = UIColor.systemBlue               // 20200826
    var lineWidth:CGFloat = 10.0
    var lineAlpha:CGFloat = 0.5

    // ------------------------------------------------------------------------------
    // 이미지 비교 가이드 라인 추가 20200924
    // ------------------------------------------------------------------------------
    var compareLineLayer = CAShapeLayer()                       // 20200924 이미지 비교 라인용(세로 모드일 경우만 보이게 함)
    var compareLineLayerOrg = CAShapeLayer()                    // 20200924 이미지 비교 라인용(세로 모드일 경우만 보이게 함)
    var compareLineApexStart = CGPoint()                        // 20200924
    var compareLineApexEnd = CGPoint()                          // 20200924
    var compareLineApexOrgStart = CGPoint()                     // 20200924
    var compareLineApexOrgEnd = CGPoint()                       // 20200924
    var compareLineControlPoint = CAShapeLayer()                // 20200924 비교 라인 control point
    var compareLineControlPointOrg = CAShapeLayer()             // 20200924 비교 라인 control point
    var compareLinePanPrevPoint = CGPoint(x:0,y:0)              // 20200924
    var isCompareLineMoving = false
    var isCompareLineMovingOrg = false  

    var ellipseLayer = CAShapeLayer()
    var outlineLayer = CAShapeLayer()                           // mark의 frame에 매칭되는 shape layer
    var controlPoints: Array<CAShapeLayer> = Array()            // control point용 배열

    // ------------------------------------------------------------------------------
    // 마크 이동, 컨트롤포인트 조절 등 이전 위치 체크에 사용
    // ------------------------------------------------------------------------------
    var panPrevPoint = CGPoint(x:0,y:0)
    var isSelectedEllipse = false
    var isSelectedControlPoint = false
    var selectedControlPoint = CAShapeLayer()                   // 선택된 control point
    var selectedControlPointPosition = -1                       // 선택된 control point의 번호.타원의 경우 0..3, 다각형의 경우 0..n-1
    
    var freeOutlineLayer = CAShapeLayer()               
    var freeLayer = CAShapeLayer()
    var freeApex = [CGPoint]()
    
    var polygonLayer = CAShapeLayer()
    var polygonApex = [CGPoint]()
    
    var polygonStatus:PolygonStatus = .DrawStopped
    var isSelectedPolygon = false
    
    var rectangleLayer = CAShapeLayer()                         // 20200826
    var isSelectedRectangle = false                             // 20200826

    //----------------------------------------------------------------------------------------
    @IBOutlet var menuButton: UIBarButtonItem!
    // 히든용 뷰를 하나 만들어서 제스처에 사용
    let hiddenView = UIView()

    // 이미지 상단 정보
    @IBOutlet var signedUserNameLabel: UILabel!
    @IBOutlet var projectNameLabel: UILabel!
    @IBOutlet var labelingOrderLabel: UILabel!
    @IBOutlet var progress: UIProgressView!
    @IBOutlet var progressLabel: UILabel!
    @IBOutlet var imageIDLabel: UILabel!
    @IBOutlet weak var markCountLabel: UILabel!
    @IBOutlet weak var markCountTitle: UILabel!
    @IBOutlet var genderLabel: UILabel!
    
    
    // 이미지 뷰 컨테이너 위에 오버레이하는 항목들
    @IBOutlet var widthSliderView: DrawLineOnWidthSliderView!
    @IBOutlet weak var widthSlider: UISlider!
    
    
    @IBOutlet weak var alphaSliderView: UIView!
    @IBOutlet weak var alphaSlider: UISlider!
    @IBOutlet weak var settedAlphaLabel: UILabel!
    
    
    @IBOutlet var filterView: UIView!       
    @IBOutlet weak var brightnessSlider: UISlider!
    @IBOutlet weak var contrastSlider: UISlider!
    @IBOutlet weak var saturationSlider: UISlider!
    
    
    @IBOutlet var wholeSwitch: UISwitch!                        // 20200819 Sub Image 전체 라벨링, 개별 라벨링
    // 이미지
    @IBOutlet var EditingImage : UIImageView!
    @IBOutlet var orgEditingImage: UIImageView!                 // 20200814
    @IBOutlet var ScrollImage: UIScrollView!
    @IBOutlet var orgScrollImage: UIScrollView!                 // 20200814
    
    // 라벨 표시 테이블
    @IBOutlet var tableViewLabelLeft: UITableView!
    @IBOutlet var tableViewLabelRight: UITableView!
    
    @IBOutlet var collectionViewBottom: UICollectionView!
    

    // 화면 하단 버튼
    @IBOutlet var undoButton: UIButton!
    @IBOutlet var redoButton: UIButton!
    @IBOutlet var clearImageButton: UIButton!
    @IBOutlet var reloadButton: UIButton!
    @IBOutlet var drawCompleteButton: UIButton!
    

    @IBOutlet weak var fastSearchView: UIView!
    @IBOutlet weak var firstFastButton: UIButton!
    @IBOutlet weak var leftFastButton: UIButton!
    @IBOutlet weak var rightFastButton: UIButton!
    @IBOutlet weak var lastFastButton: UIButton!
    @IBOutlet var firstButton: UIButton!
    @IBOutlet var leftButton: UIButton!
    @IBOutlet var rightButton: UIButton!
    @IBOutlet var lastButton: UIButton!
    @IBOutlet var saveButton: UIButton!
    var isTotalExplore:Bool = true
    var fastSearch:Bool = false
    
    // 마크 타입/색상 선택 관련
    @IBOutlet var lineTypeSegmented: UISegmentedControl!
    let defaultLineType = 1
    @IBOutlet var lineColorSegmented: UISegmentedControl!
    @IBOutlet weak var cutModeSegmented: UISegmentedControl!
    var isCutMode:Bool = false
    
    @IBOutlet var labelLeftTitle: UILabel!
    @IBOutlet var labelRightTitle: UILabel!
    
    @IBOutlet var bottomEditMarkInfoView: UIView!
    //@IBOutlet var markSelectionButton: UIButton!
    
    // ------------------------------------------------------------------------------
    // 현재 이미지 인덱스 번호 선언
    // ------------------------------------------------------------------------------
    
    @IBOutlet weak var collectionViewMainImage: UICollectionView!
    var currentImageIndex = -1
    var image_last_row_num:Int = -1 // 서버로부터 가져온 메인 이미지 목록의 마지막 번호
    var image_count:Int = 0
    var mainImageNeedDownLoad = true
    

    // ------------------------------------------------------------------------------
    // 메인 이미지뷰에 보여줄 실제 이미지 파일을 서버로부터 가져와서 설정
    // ------------------------------------------------------------------------------
    var realImage:UIImage?
    var realImageWHRatio:Float?         // 실제이미지의 높이 대비 폭 비율
    var scrollImageWHRatio:Float?       // 스크롤 영역의 높이 대비 폭 비율
    var imageRealViewRatio:Float?       // 이미지뷰와 실제이미지의 비율(실제 이미지뷰 높이(폭) 대비 이미지뷰의 높이(폭)
    var existImage = false

    
    // ------------------------------------------------------------------------------
    // 이미지 라벨링 갯수 저장용
    // ------------------------------------------------------------------------------
    var total_count = 0     // 전체 이미지 갯수
    var complete_count = 0  // 완료 이미지 갯수
    var more_image = "N"    // 이미지가 더 있는지...
    var sub_total_count = 0     // sub 전체 이미지 갯수 20200820
    var sub_complete_count = 0  // sub 완료 이미지 갯수 20200820

    // ------------------------------------------------------------------------------
    // 이미지 네비게이션 버튼 중 무엇이 선택되었는가
    // P:Prev, N:Next, L:Last, F:First, R:Random(랜덤은 서버 프로시저에서 차수가 1이 아닌 경우 체크하여 수행)
    // ------------------------------------------------------------------------------
    var FPNLFlag: String = "N"

    var errorMessage: String = "Error~"

    // ------------------------------------------------------------------------------
    // Marking 활성화 여부
    // ------------------------------------------------------------------------------
    var markEnabled = false
    
    // ------------------------------------------------------------------------------
    // 리뷰 모드시에 마크가 수정이 되었는지 여부, 수정이 되었으면 마크 이미지를 새로 업로드, 그렇지 않으면 안올림
    // ------------------------------------------------------------------------------
    var markUpdated = false
    var loadedMarkNum:Int = 0

    // ------------------------------------------------------------------------------
    // color
    // ------------------------------------------------------------------------------
    //let defaultCellBackgroundColor = UIColor.init(red: 232/255.0, green: 232/255.0, blue: 232/255.0, alpha: 1.0)
    let defaultCellBackgroundColor = UIColor.groupTableViewBackground
    let defaultCellTextColor = UIColor.black
    let selectedCellBackgroundColor = UIColor.orange
    let selectedCellTextColor = UIColor.white

    var labelsLeft = ["Negative", "Positive"]
    var labelsRight = ["Negative", "Positive"]
    
    var imageInfo:ImageInfo = ImageInfo()
    
    var selectedLabelLeftIndex = -1
    var selectedLabelRightIndex = -1
    var tableViewCellHeight = 10

    // ------------------------------------------------------------------------
    // 서버에 있는 소스 이미지를 다운로드 및 저장 : return : 이미지 저장 위치+파일명
    // ------------------------------------------------------------------------
    let sourceImageDirectoryName = "SourceImage"
    let orgSourceImageDirectoryName = "OrgImage"        // 20200818
    let markedImageDirectoryName = "MarkedImage"
    var sourceImageDirectoryURL:URL?
    var orgSourceImageDirectoryURL:URL?                 // 20200818
    var markedImageDirectoryURL:URL?
    let markedImageNameSuffix = "_Mark"

    // ---------------------------------------------------------------------------------------
    // 레이아웃 관련 변수 정의
    // ---------------------------------------------------------------------------------------
    var constraints = [NSLayoutConstraint]()
    var collectionViewThumbnailWidthInPortraitMode:CGFloat = 90.0
    
    var tableViewLeftLeftConstant:CGFloat = 0
    var lineTypeSegmentedHeight:CGFloat = 35.0
    var lineTypeSegmentedWidth:CGFloat = 240.0
    var lineColorSegmentedWidth:CGFloat = 180.0
    var collectionThumbnailTopConstant:CGFloat = 75
    var lineTypeSegmenedTopConstant:CGFloat = 75
    
    // ---------------------------------------------------------------------------------------
    // Thumnail 관련
    // ---------------------------------------------------------------------------------------
    
    
    @IBOutlet weak var thumbnailGroupView: UIView!
    @IBOutlet weak var collectionViewThumbGroup: UICollectionView!
    var selectedGroupName:String = ""
    var selectedGroupIndex:Int = -1
    
    @IBOutlet weak var collectionViewThumbnail: UICollectionView!

    var subImageArray:[SubImageInfo] = [SubImageInfo]()
    var last_row_num:Int = -1                                    // 섬네일컬렉션뷰
    var sub_image_count:Int = 0
    var selectedSubImageId:String = ""
    var selectedSubImageRowNum:Int = -1
    var sumImageNeedDownLoad = true

    // ------------------------- 메뉴 처리/Segue 처리  from ----------------------------------
    // menu 버튼 tab하면 메뉴 뷰 나오게 함
    let menuTransition = SlideMenuInTransition()
    var menuViewController:MenuVC = MenuVC()
    
    @IBAction func didTapMenu(_ sender: UIBarButtonItem) {
        menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuVC") as! MenuVC
        
        menuViewController.didTopMenuType = { menuType in
            p(menuType)
            self.transitionToNewContent(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self // transitioningdeligate 설정
        present(menuViewController, animated: true)
        
        // 홈화면 위를 흐리게 하기 위해서 dimming view를 사용
        // dimming view를 탭하면 메뉴 뷰 사라지게 함
        setupDimmingViewTapGestureRecognizer(view: menuTransition.dimmingView)
        
    }
    

    // -----------------------------------------------------------------------------
    // 특정 화면에서 복귀할 때 다시 메뉴를 보여줄지를 담는 변수
    // -----------------------------------------------------------------------------
    var displayMenuView = false


    @IBAction func returnFromsegueAction(segue : UIStoryboardSegue) {
        returnFromOtherScreen(segue: segue)
    }

    // ------------------------- 메뉴 처리/Segue 처리 to ----------------------------------

    
    // 검토 설정 begin
    
    
    @objc func didTapReviewSetting(_ sender: UIButton) {

        performSegue(withIdentifier: "segueReviewSetting", sender: self)
    }
    

    func initLabelingSettingItem() {
        
        IsReviewMode = false
        IncludeLabelingDoneImage = true
        wholeSwitch.isOn = false                // 20200819 기본 모드는 개별 이미지 작업 모드
        
        isTotalExplore = IncludeLabelingDoneImage
        LeftIndexOnReviewMode = -1
        RightIndexOnReviewMode = -1
        
        self.title = "라벨링 메인"
        
        _ = removeDir(fullPath: sourceImageDirectoryURL!.path)
        _ = removeDir(fullPath: markedImageDirectoryURL!.path)
        _ = removeDir(fullPath: orgSourceImageDirectoryURL!.path)   // 20200818
    }
    
    func setLabelingSettingItem() {
        isTotalExplore = IncludeLabelingDoneImage

        if (IsReviewMode) {
            self.title = "라벨링 메인 (리뷰 모드)"

            if (!naviBarBlinkRunning) {
                naviBarBlinkStart()
            }
        }
        else {
            self.title = "라벨링 메인"

            self.navigationController?.navigationBar.barTintColor = UIColor.white
            if (naviBarBlinkRunning) {
                naviBarBlinkStop()
            }
        }
    }
    
    // 검토 설정 end
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        let ud = MyUserDefaults()
        ud.getUserDefaultAfterDidBecomeActive()
        
        // 이미지 디렉토리 URL 지정
        sourceImageDirectoryURL = DocumentsDirectoryURL.appendingPathComponent(sourceImageDirectoryName)
        markedImageDirectoryURL = DocumentsDirectoryURL.appendingPathComponent(markedImageDirectoryName)
        orgSourceImageDirectoryURL = DocumentsDirectoryURL.appendingPathComponent(orgSourceImageDirectoryName) // 20200818

        self.title = "라벨링 메인"
        let reloadItem = UIBarButtonItem(image: #imageLiteral(resourceName: "Reload-50"), style: .plain, target: self, action: #selector(reloadImageList(_:)))
        let loadSettingViewItem  = UIBarButtonItem(title: "리뷰모드설정", style: .plain, target: self, action: #selector(didTapReviewSetting(_:)))
        //self.navigationItem.rightBarButtonItems = [reloadItem, loadSettingViewItem] 20200823
        self.navigationItem.rightBarButtonItems = [reloadItem]

        // 히든용 뷰를 하나 만들어서 제스처에 사용
        setHiddenView(view: hiddenView)
        checkHiddenView()
 
        setLineColorSegmented()
        
        initObjectsInView()
        initTableViewProperty()
        initCollectionViewProperty()
        initImageViewProperty()
        initOrgImageViewProperty()

        initGesture()
        addGestureForMarking(lineType: .FreeCurve)
        
        initLabelingSettingItem()
        
        setupImageView()
        setupImageCollectionView()
        setupMainImageCollectionView()
        setupThumbGroupCollectionView()
        
        setControlButtonPropertyUpperImage(button: clearImageButton)
        setControlButtonPropertyUpperImage(button: undoButton)
        setControlButtonPropertyUpperImage(button: redoButton)
        setControlButtonPropertyUpperImage(button: reloadButton)
        setDrawCompleteButtonProperty()
        
        // 직사각형을 기본으로 설정
        lineTypeSegmented.selectedSegmentIndex = defaultLineType
        didTapLineTypeSegmented(lineTypeSegmented)
        
        resetSubImageList()

        // --------------------------------------------------------------------------
        // 이미지 상단 컨트롤 레이아웃 수동 지정을 위한 자동 레이아웃 설정 disable
        // --------------------------------------------------------------------------
        disableAutoresizingMask()
        
        widthSliderViewSetNeedsDisplay()
        
    }
    
    func widthSliderViewSetNeedsDisplay() {
        widthSliderView.lineColor = lineColor
        widthSliderView.lineWidth = lineWidth * ScrollImage.zoomScale
        widthSliderView.setNeedsDisplay()
    }
    
    // --------------------------------------------------------------------------
    // 이미지 상단 컨트롤 버튼 속성 설정
    // --------------------------------------------------------------------------
    func setControlButtonPropertyUpperImage(button:UIButton) {
        button.backgroundColor = .groupTableViewBackground
        button.layer.cornerRadius = 3.5
        button.layer.borderWidth = 1
        button.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        button.frame = CGRect(x: drawCompleteButton.frame.origin.x, y: lineTypeSegmented.frame.origin.y, width: drawCompleteButton.frame.width, height: lineTypeSegmented.frame.height)
    }
    
    // --------------------------------------------------------------------------
    // 이미지 상단 컨트롤 버튼 tint color 변경시 보더 컬러 색상 변경
    // --------------------------------------------------------------------------
    func setControlButtonBorderColorUpperImage() {
        drawCompleteButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        clearImageButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        undoButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        redoButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        reloadButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
    }
    
    // --------------------------------------------------------------------------
    // 이미지 상단 그리기 완료 버튼 속성 설정
    // --------------------------------------------------------------------------
    func setDrawCompleteButtonProperty() {
        drawCompleteButton.isHidden = true
        drawCompleteButton.backgroundColor = .groupTableViewBackground
        drawCompleteButton.layer.cornerRadius = 3.5
        drawCompleteButton.layer.borderWidth = 1
        drawCompleteButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        drawCompleteButton.frame = CGRect(x: drawCompleteButton.frame.origin.x, y: lineTypeSegmented.frame.origin.y, width: drawCompleteButton.frame.width, height: lineTypeSegmented.frame.height)
    }
    
    @objc func showLoginView() {
        performSegue(withIdentifier: "segueLogin", sender: nil)
    }
    
    @objc func showProjectSettingView() {
        if (!isLogin) {
            self.view.showToast(toastMessage: "로그인된 정보가 없습니다.", duration: 1.5)
            return
        }
        performSegue(withIdentifier: "segueProjectList", sender: nil)
    }
    
    // ---------------------------------------------------------------------
    // 하나하나 건너 뛸 것인지 라벨링을 하지 않은 이미지로 건너 뛸 것인지 결정하는 스위치
    // ---------------------------------------------------------------------
    @objc func explorerSwitchStateDidChange(_ sender:UISwitch){
        if (sender.isOn == true){
            p("UISwitch state is now ON")
        }
        else{
            p("UISwitch state is now Off")
        }
    }

    // ---------------------------------------------------------------------
    // 이미지 목록 갱신
    // ---------------------------------------------------------------------
    @objc func reloadImageList(_ sender: UIButton) {

        if (!isWorking) { return }
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        DoEvents(f: 0.01)
        
        clearLabelImage()
        loadData()

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
    }

    // ---------------------------------------------------------------------
    // viewWillAppear
    // ---------------------------------------------------------------------
    var beforeOrientation = OrientationValue
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        SetOrientation()
        
        if (displayMenuView) {
            if (isLogin && isWorking) {
            }
            else {
                didTapMenu(menuButton)
                displayMenuView = false
            }
        }

        checkHiddenView()
        
    }
    
    var lastSelectedIndex = -1
    var befTintColor:UIColor = GetTintColor()
    // ---------------------------------------------------------------------
    // viewDidAppear
    // ---------------------------------------------------------------------
    override func viewDidAppear(_ animated: Bool) {

        super.viewDidAppear(animated)

        // 이미지 파일 자동 업로드                            // 20200830 세로 가로 모드 체크 전으로 이동
        autoUpload.start()
        
        // 틴트 색상이 변경되었으면 다시 그리기 위해서.. tableview와 collection 뷰의 선택된 항목은 tint색상으로 하기 때문임
        if (befTintColor != GetTintColor()) {
            tableViewLabelLeft.reloadData()
            tableViewLabelRight.reloadData()
            collectionViewMainImage.reloadData()
            collectionViewBottom.reloadData()
            collectionViewThumbnail.reloadData()
            collectionViewThumbGroup.reloadData()
            befTintColor = GetTintColor()
        }
        
        if (beforeOrientation != OrientationValue) {
            didTapDrawCompleteButton(self)
            //reloadClick(self)                         // 20200830
            //setupImageView()
            beforeOrientation = OrientationValue
            if !FirstDidBecomeActive {                  // 20200830
                return
            }
        }

        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = self.view.frame
        self.view.addSubview(child.view)
        child.didMove(toParent: self)
        
        DoEvents(f: 0.01)     // 20200827
        
        if (FirstDidBecomeActive) {
            checkLoginOutInfo(newLogin: isLogin)
            addGestureForCompareLine()              // 20200924
            drawCompareLine()                       // 20200924
            FirstDidBecomeActive = false
        }
        
        if (isFromLoginMenu) {
            p("---------------------------------------------------------- isFromLoginMenu")
            if (isNewLogined) {
                WorkingImageIndex = 0
                WorkingSubImageIndex = 0
                LabelList.arrayLabelInfo.removeAll()
                initLabelingSettingItem()
            }
            checkLoginOutInfo(newLogin: isNewLogined)
            isFromLoginMenu = false
        }
        else if (isFromProjectMenu) {
            p("---------------------------------------------------------- isFromProjectMenu")
            if (isNewProjectBegan) {
                WorkingImageIndex = 0
                WorkingSubImageIndex = 0
                LabelList.arrayLabelInfo.removeAll()
                initLabelingSettingItem()
            }
            checkWorkingProjectInfo(newProject: isNewProjectBegan)
            isFromProjectMenu = false
            
        }
        else if (isFromSettingMenu) {
            p("---------------------------------------------------------- isFromSettingMenu")
            if (IsSettingValueChanged) {

                setLabelingSettingItem()
                resetObjectsRelatedToLabeling()
                
                if (IsReviewMode) {

                    lastSelectedIndex = currentImageIndex       // 일반 탐색 모드 최종 조회 index 저장하여 돌아올때 사용
                    imageArray = mainImageList.doneImagesByResult(leftValue: LeftIndexOnReviewMode, rightValue: RightIndexOnReviewMode)
                    
                    currentImageIndex = imageArray.count - 1
                    self.collectionViewMainImage.reloadData()

                    if (currentImageIndex >= 0) {
                        let indexPath = IndexPath(item: currentImageIndex, section: 0)
                        
                        DispatchQueue.main.async {
                            self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
                            DoEvents(f: 0.01)
                        }
                        
                        loadImageFromURL(index: currentImageIndex)    // 이미지를 가져옴
                        setLabelTouchEnable(enable: true)
                    }
                    else {
                        view.showToast(toastMessage: "해당하는 이미지가 없습니다.", duration: 1.5)
                        setLabelTouchEnable(enable: false)
                    }
                    
                }
                else {

                    imageArray = mainImageList.images
                    
                    // 리뷰 모드에서 일반 모드로 돌아올때 최종 조회했던 index로 전환
                    p("imageArray.count, lastSelectedIndex, currentImageIndex: \(imageArray.count), \(lastSelectedIndex), \(currentImageIndex)")
                    currentImageIndex = (lastSelectedIndex < 0) ? currentImageIndex : lastSelectedIndex
                    self.collectionViewMainImage.reloadData()
                    
                    if (imageArray.count == 0) {
                        setLabelTouchEnable(enable: false)
                    }
                    else {
                        if (currentImageIndex < 0) {
                            currentImageIndex = 0
                        }
                        if (currentImageIndex < imageArray.count) {
                            let indexPath = IndexPath(item: currentImageIndex, section: 0)
                            
                            DispatchQueue.main.async {
                                self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
                                DoEvents(f: 0.01)
                            }
                            
                            loadImageFromURL(index: currentImageIndex)    // 이미지를 가져옴
                        }
                        setLabelTouchEnable(enable: true)
                    }
                    
                }
                setProgressValue()
                IsSettingValueChanged = false
            }
            isFromSettingMenu = false
        }

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()

    }
    
    // ---------------------------------------------------------------------
    // viewWillDisappear
    // ---------------------------------------------------------------------
    override func viewWillDisappear(_ animated: Bool) {
        AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.all)
    }
    
    
    // ---------------------------------------------------------------------
    // viewDidDisappear
    // ---------------------------------------------------------------------
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        autoUpload.stop()
    }
    
    // ---------------------------------------------------------------------
    // viewWillLayoutSubviews
    // ---------------------------------------------------------------------
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        adjustLabelListViewLocation()
        
    }
    
    // ---------------------------------------------------------------------
    // viewDidLayoutSubviews
    // ---------------------------------------------------------------------
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setControlButtonBorderColorUpperImage()

        tableViewLabelLeft.reloadData()
        tableViewLabelRight.reloadData()
        collectionViewBottom.reloadData()
        collectionViewThumbGroup.reloadData()
    }

    func setHiddenView(view: UIView) {
        view.frame = self.view.frame
        view.backgroundColor = UIColor.white
        view.alpha = 0.35
        view.isHidden = true
        self.view.addSubview(view)
    }

    //---------------------------------------------------------------------------
    // line drawing color segmented control
    //---------------------------------------------------------------------------
    func setLineColorSegmented() {

        lineColorSegmented.removeAllSegments()
        for item in EnumDrawingColor.allCases {
            let title = EnumDrawingColor(rawValue: item.rawValue)?.title
            let color = EnumDrawingColor(rawValue: item.rawValue)?.displayColor
            let index = lineColorSegmented.numberOfSegments
            lineColorSegmented.insertSegment(withTitle: title, at: index, animated: false)
            (lineColorSegmented.subviews[index] as UIView).tintColor = color
        }
        lineColorSegmented.selectedSegmentIndex = 0
        
    }

    // --------------------------------------------------------------------------
    // 화면 상의 버튼 등 오브젝트 등의 속성 초기화
    // --------------------------------------------------------------------------
    func setProgressValue() {
        
        total_count = IsReviewMode ? mainImageList.doneImages().count : mainImageList.count
        complete_count = IsReviewMode ? imageArray.count : mainImageList.doneImages().count
        
        if (total_count == 0) {
            progress.progress = 0
            progressLabel.text = (WorkingProjectMulti == "Y") ? "[0%(0/0)],[0/0]" : "0%(0/0)"
            return
        }

        // 20200820 sub 이미지 관련 추가
        sub_total_count = IsReviewMode ? subImageList.doneImages().count : subImageList.count
        sub_complete_count = IsReviewMode ? subImageArray.count : subImageList.doneImages().count
        
        // 이미지 랜덤 가져오는 부분에서 전체수와 완료를 가져와서 해당 변수에 저장한 것을 사용
        let value = Float(complete_count) / Float(total_count)
        progress.progress = value
        
        if (WorkingProjectMulti == "Y") {
            progressLabel.text = String(format: "[%4.1f%%(%d%/%d)][%d%/%d]", value * 100, complete_count, total_count, sub_complete_count, sub_total_count)
        }
        else {
            progressLabel.text = String(format: "%4.1f%%(%d%/%d)", value * 100, complete_count, total_count)
        }
        
        if (complete_count == total_count) {
            progressLabel.textColor = UIColor.red
        }
        else if (sub_complete_count == sub_total_count) {
            progressLabel.textColor = UIColor.blue
        }
        else {
            progressLabel.textColor = UIColor.black
        }

    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        // ---------------------------------------------------------------------
        // 20200830
        // ---------------------------------------------------------------------
        if (size.width > self.view.frame.size.width) {
            p("----------- Landscape")
        } else {
            p("----------- Portrait")
        }
        
        ScrollImage.zoomScale = 1.0     // 이걸 해줘야 제대로 위치에 다시 그림...
        
        if (size.width != self.view.frame.size.width) {
            DispatchQueue.main.async {
                self.redrawMarkAll()
                self.addGestureForCompareLine()                 // 20200924
                self.drawCompareLine()                          // 20200924
            }
        }
        // ---------------------------------------------------------------------

    }
    
    func initObjectsInView() {
        
        filterView.isHidden = true  // 20200819 서울대병원은 색상 조정 필요 없어서 히든처리
        
        // 하단 네비게이션 툴바 히든 처리
        self.navigationController?.toolbar.isHidden = true
        
        // 진행률 오브젝트
        progress.transform = CGAffineTransform(scaleX: 1, y: 5)
        progress.clipsToBounds = true
        setProgressValue()

        // mark reset/undo/redo
        clearImageButton.isEnabled = true
        undoButton.isEnabled = true
        redoButton.isEnabled = true

        saveButton.isEnabled = false

        // 하단 버튼 모양 변경(둥글게)
        buttonRadius(saveButton)
        
        // undo redo 활성화 여부
        undoredoEnable()
    }
    
    // --------------------------------------------------------------------------
    // 버튼 코너 둥글게
    // --------------------------------------------------------------------------
    func buttonRadius(_ button: UIButton) {
        button.layer.backgroundColor = UIColor.init(red: 232/255.0, green: 232/255.0, blue: 232/255.0, alpha: 1.0).cgColor
        button.layer.cornerRadius = 10;
        button.clipsToBounds = true;
    }
    
    // --------------------------------------------------------------------------
    // 라벨링 작업과 관련된 오브젝트 리셋(이미지가 변경될 때)
    // --------------------------------------------------------------------------
    func resetObjectsRelatedToLabeling() {
        // 라벨 관련
        selectedLabelLeftIndex = -1
        selectedLabelRightIndex = -1
        tableViewLabelLeft.reloadData()
        //p("resetObjectsRelatedToLabeling call tableViewLabelRight.reloadData() ")
        tableViewLabelRight.reloadData()
        collectionViewBottom.reloadData()
        
        // 버튼 관련
        saveButton.isEnabled = false
    }
    
    // --------------------------------------------------------------------------
    // 라벨 목록을 보여주는 좌.우 테이블뷰의 속성 초기화
    // --------------------------------------------------------------------------
    func initTableViewProperty() {
        // tableView delegate, datasource 설정
        tableViewLabelLeft.delegate = self
        tableViewLabelLeft.dataSource = self
        tableViewLabelLeft.tag = 0

        // tableView 2개를 사용하기 위하여 등록해야 함
        tableViewLabelLeft.register(UITableViewCell.self, forCellReuseIdentifier: "LabelCellLeft")
        
        tableViewLabelRight.delegate = self
        tableViewLabelRight.dataSource = self
        tableViewLabelRight.tag = 1

        // tableView 2개를 사용하기 위하여 등록해야 함
        tableViewLabelRight.register(UITableViewCell.self, forCellReuseIdentifier: "LabelCellRight")
    }
    
    func initCollectionViewProperty() {
        // collectionView delegate, datasource 설정
        collectionViewBottom.delegate = self
        collectionViewBottom.dataSource = self
        collectionViewBottom.tag = 0
    }

    // --------------------------------------------------------------------------
    // 메인 이미지뷰 속성 설정 및 초기 이미지 설정
    // --------------------------------------------------------------------------
    func initImageViewProperty() {
        EditingImage.isUserInteractionEnabled = true
        noticeClearMark = false
        EditingImage.clipsToBounds = true
        EditingImage.backgroundColor = UIColor.darkGray

        // 초기 이미지 설정
        EditingImage.image = #imageLiteral(resourceName: "서울대병원야경")
        EditingImage.contentMode = .scaleToFill
        
        originalImage = EditingImage.image
        resetImageFilter()
    }
    
    // --------------------------------------------------------------------------
    // 원본 이미지뷰 속성 설정 및 초기 이미지 설정
    // --------------------------------------------------------------------------
    func initOrgImageViewProperty() {
        orgEditingImage.isUserInteractionEnabled = true
        orgEditingImage.clipsToBounds = true
        orgEditingImage.backgroundColor = UIColor.darkGray

        // 초기 이미지 설정
        orgEditingImage.image = #imageLiteral(resourceName: "서울대병원야경")
        orgEditingImage.contentMode = .scaleToFill
    }
    
    // ------------------------------------------------------------------------------
    // 로그인/아웃시 체크(최초 로딩시에도 수행)
    // ------------------------------------------------------------------------------
    @objc func checkLoginOutInfo(newLogin new_login:Bool) {
        
        if (new_login) {
            signedUserNameLabel.text = LoginName
            clearLabelImage()
            // 라벨링 중인 작업이 있으면 Loading
            if (isWorking) {
                loadData()
            }
            // 라벨링 작업중인 것이 없으면 프로젝트 목록 화면으로 이동
            else {
                DispatchQueue.main.async() {
                    self.performSegue(withIdentifier: "segueProjectList", sender: nil)
                }
            }
        }
        else {
            if (!isLogin) {
                signedUserNameLabel.text = "not logged in"
                clearLabelImage()
                // 맨처음 로딩 했을 경우에만 체크하여 로그인 페이지로 이동
                if (FirstDidBecomeActive) {
                    DispatchQueue.main.async() {
                        self.performSegue(withIdentifier: "segueLoginOut", sender: nil)
                    }
                }
            }
        }
        
    }
    
    // ------------------------------------------------------------------------------
    // 프로젝트 및 차수 선택 후 라벨링 시작 및 종료시 체크
    // ------------------------------------------------------------------------------
    @objc func checkWorkingProjectInfo(newProject new_project:Bool) {
        if (new_project) {
            clearLabelImage()
            if (isWorking) {
                loadData()
            }
        }
        else {
            if (!isWorking) {
                clearLabelImage()
            }
        }
    }
    
    func clearLabelImage() {
        // project Info
        projectNameLabel.text = "________________________"
        labelingOrderLabel.text = "__"

        // 전역 변수 목록
        mainImageList.removeAll()

        imageIDLabel.text = " "
        setProgressValue()

        // 내부 변수
        canvas.clear()
        markCountLabel.text = "\(canvas.lines.count)개"

        undoredoEnable()
        resetObjectsRelatedToLabeling()
        
    }
    

    
    func showNotRegisterdMessage() {
        if (currentImageIndex < 0 || currentImageIndex > imageArray.count) {
            p("Array Index Error : showNotRegisterdMessage() number \(currentImageIndex)")
            return
        }
        guard let imageId = imageArray[currentImageIndex].id else { return }
        self.view.showToast(toastMessage: "\n" + imageId + "\n\n서버에 이미지가 등록되지 않았습니다.\n", duration: 1.5)
    }

    // ------------------------------------------------------------------------------
    // 이미지 파일 url 변수 정의
    // ------------------------------------------------------------------------------
    var savedMarkedImageUrlPath:String?
    var savedJsonFileUrlPath:String?                    // 20200828
    var savedSourceImageUrlPath:String?
    var orgSavedSourceImageUrlPath:String?              // 20200818


    var isExistSelectedMark = false                     // 선택된 mark가 있는지

    var isExistSelectedControlPoint = false             // 선택된 control point가 있는지

    var lastScale:CGFloat!
    
    func disableAnimation(_ closure:()->Void){
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        closure()
        CATransaction.commit()
    }
    
    // IBAction Process
    @IBAction func undoMark(_ sender: Any) {
        canvas.undo()
        markCountLabel.text = "\(canvas.lines.count)개"
        undoredoEnable()
        markUpdated = true  // 20200829
    }

    @IBAction func RedoMark(_ sender: Any) {
        canvas.redo()
        markCountLabel.text = "\(canvas.lines.count)개"
        undoredoEnable()
    }
    
    func checkHiddenView() {
        if (mainImageList.count == 0) {
            hiddenView.isHidden = false
        }
        else {
            hiddenView.isHidden = true
        }
    }
    
    @IBAction func widthSliderChanged(_ sender: Any) {
        let currentValue:Float = widthSlider.value * 20
        let roundedValue = roundf(currentValue * 10) / 10
        lineWidth = CGFloat(roundedValue)

        widthSliderViewSetNeedsDisplay()
    }
    
    @IBAction func alphaSliderChanged(_ sender: UISlider) {
        let currentValue:Float = alphaSlider.value
        let roundedValue = roundf(currentValue * 10) / 10
        settedAlphaLabel.text = "\(roundedValue)"
        lineAlpha = CGFloat(roundedValue)
        
        for index in 0 ..< canvas.lines.count {
            canvas.lines[index].alpha = lineAlpha
        }

        canvas.setNeedsDisplay()
    }
    
    
    // ----------------------------------------------------------------------
    // Image filter
    // ----------------------------------------------------------------------
    var filter:CIFilter! = CIFilter()
    var context = CIContext()
    var filteredImage:CIImage? = CIImage()
    var sliderValue:Float?
    var originalImage:UIImage?

    // ----------------------------------------------------------------------
    // brightness 수집
    // ----------------------------------------------------------------------
    @IBAction func brightnessSliderChanged(_ sender: UISlider) {
        let roundedValue = roundf(sender.value * 100) / 100
        sender.value = roundedValue
        setImageFilter()
        sliderValue = sender.value
    }
    
    @IBAction func brightnessSliderTouchUp(_ sender: UISlider) {
        sender.value = sliderValue!
        print("brightnessSliderTouchUp : \(sender.value)")
    }
    
    // ----------------------------------------------------------------------
    // contrast 수집
    // ----------------------------------------------------------------------
    @IBAction func contrastSliderChanged(_ sender: UISlider) {
        let roundedValue = roundf(sender.value * 10) / 10
        sender.value = roundedValue
        setImageFilter()
        sliderValue = sender.value
    }
    
    @IBAction func contrastSliderTouchUp(_ sender: UISlider) {
        sender.value = sliderValue!
        print("contrastSliderTouchUp : \(sender.value)")
    }

    // ----------------------------------------------------------------------
    // saturation 수집
    // ----------------------------------------------------------------------
    @IBAction func saturationSliderChanged(_ sender: UISlider) {
        let roundedValue = roundf(sender.value * 10) / 10
        sender.value = roundedValue
        setImageFilter()
        sliderValue = sender.value
    }
    
    
    @IBAction func saturationSliderTouchUp(_ sender: UISlider) {
        sender.value = sliderValue!
        print("saturationSliderTouchUp : \(sender.value)")
    }

    // ----------------------------------------------------------------------
    // 이미지 필터 초기화
    // ----------------------------------------------------------------------
    @IBAction func removeFilterButtonClicked(_ sender: UIButton) {
        EditingImage.image = originalImage
        resetImageFilter()
    }

    func resetImageFilter() {
        brightnessSlider.value = 0.0
        contrastSlider.value = 1.0
        saturationSlider.value = 1.0
    }

    // ----------------------------------------------------------------------
    // 이미지에 설정된 필터 한꺼번에 세팅. 따로따로 하면 안됨
    // ----------------------------------------------------------------------
    func setImageFilter() {
        EditingImage.image = originalImage
        let beginImage = CIImage(image: EditingImage.image!)
        self.filter = CIFilter(name: "CIColorControls")!
        self.filter?.setValue(beginImage, forKey: kCIInputImageKey)
        self.filter.setValue(brightnessSlider.value, forKey: kCIInputBrightnessKey)
        self.filter.setValue(contrastSlider.value, forKey: kCIInputContrastKey)
        self.filter.setValue(saturationSlider.value, forKey: kCIInputSaturationKey)
        self.filteredImage = self.filter?.outputImage
        EditingImage.image = UIImage(cgImage: self.context.createCGImage(self.filteredImage!, from: (self.filteredImage?.extent)!)!)
    }
    // ----------------------------------------------------------------------

    
    // ----------------------------------------------------------------------
    // 전체/개별 작업 모드 설정 20200819
    // ----------------------------------------------------------------------
    @IBAction func wholeSwitchTriggered(_ sender: UISwitch) {
        
        var message = "전체 이미지 작업 모드입니다."
        if (!sender.isOn) {
            loadSubImageLabelingResult(selectedSubImageRowNum)
            message = "개별 이미지 작업 모드입니다."
        }
        else {
            loadLabelingResult(currentImageIndex)
        }
        self.view.showToast(toastMessage: message, duration: 0.6)
    }
    

    // ----------------------------------------------------------------------
    // 라벨링 결과와 마킹 결과 저장 버튼 클릭시
    // ----------------------------------------------------------------------
    @IBAction func didTapSaveButton(_ sender: Any) {
        
        // 전체 이미지 작업 모드일 경우에는 확인을 받는다. 20200819
        if wholeSwitch.isOn {
            let dialogMessage = UIAlertController(title: "확인", message: "전체 이미지에 동일 라벨을 적용하시겠습니까?", preferredStyle: .alert)
            let ok = UIAlertAction(title: "예", style: .destructive, handler: { (action) -> Void in
                self.execSave()
            })
            let cancel = UIAlertAction(title: "아니오", style: .cancel) { (action) -> Void in
            }
            dialogMessage.addAction(ok)
            dialogMessage.addAction(cancel)
            self.present(dialogMessage, animated: true, completion: nil)
        }
        else {
            execSave()
        }
        
    }
    
    // -----------------------------------------------------------------------------
    // 실제 라벨링 결과 저장 20200819. didTapSaveButton에서 빼서 함수로 변경함
    // -----------------------------------------------------------------------------
    func execSave() {
        didTapDrawCompleteButton(self)
        
        // save하기 전에 원래대로 필터가 없는 원본이미지를 매핑
        EditingImage.image = originalImage
        resetImageFilter()
        
        if (!existImage) {
            showNotRegisterdMessage()
            return
        }
        
        saveLabelingResultAndMark()
    }
    
    // -----------------------------------------------------------------------------
    // 저장버튼 활성화 여부 결정
    // -----------------------------------------------------------------------------
    func checkSaveButtonShow() {
        
        // 등록된 이미지가 없는 경우
        if (!existImage) {
            saveButton.isEnabled = false;
            return;
        }
        
        // 좌측 라벨 목록이 존재하면...
        if (LabelList.getLabelCount(location: 0) > 0) {
            // 좌,우측 라벨 목록이 모두 존재하면...
            if (LabelList.getLabelCount(location: 1) > 0) {
                saveButton.isEnabled = (selectedLabelLeftIndex < 0 || selectedLabelRightIndex < 0) ? false : true;
            }
                // 좌측 라벨 목록만 존재하면...
            else {
                saveButton.isEnabled = selectedLabelLeftIndex < 0 ? false : true;
            }
        }
        else {
            // 우측 라벨 목록만 존재하면...
            if (LabelList.getLabelCount(location: 1) > 0) {
                saveButton.isEnabled = selectedLabelRightIndex < 0 ? false : true;
            }
                // 좌,우측 라벨 목록이 모두 없으면...
            else {
                saveButton.isEnabled = false;
            }
        }
    }
    
    var beforeleftButtonisEnabled = true;
    var beforerightButtonisEnabled = true;
    var beforefirstButtonisEnabled = true;
    var beforelastButtonisEnabled = true;
    var beforeImageID = ""

    // -----------------------------------------------------------------
    // 마크 모양 세그멘티드뷰 선택시
    // -----------------------------------------------------------------
    @IBAction func didTapLineTypeSegmented(_ sender: Any) {
        
        // 이전 상황이 타원 및 다각형인 경우에는 강제로 완료버튼을 tap
        if (lineType == .Ellipse || lineType == .Polygon || lineType == .Rectangle) {
            didTapDrawCompleteButton(self)
        }
        
        switch lineTypeSegmented.selectedSegmentIndex {
        case 0:
            lineType = LineType.FreeCurve
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = false
//        case 1:
//            lineType = LineType.ClosedCurve
//            drawCompleteButton.isHidden = true
//            widthSliderView.isHidden = true
        case 1:
            lineType = LineType.Rectangle         // 20200826
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = true
        case 2:
            lineType = LineType.Ellipse
            drawCompleteButton.isHidden = false
            widthSliderView.isHidden = true
        case 3:
            lineType = LineType.Polygon
            drawCompleteButton.isHidden = false
            widthSliderView.isHidden = true
        case 4:
            lineType = LineType.Eraser
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = true
        default:
            lineType = LineType.FreeCurve
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = true
        }
        if (!drawCompleteButton.isHidden) {
            drawCompleteButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        }
        
        // 마킹용 제스처 설정 호출
        addGestureForMarking(lineType: lineType)
    }

    // -----------------------------------------------------------------
    // 다각형 마크의 경우 long press로 완료 처리하는 것과 동일한 버튼 클릭
    // -----------------------------------------------------------------
    @IBAction func didTapDrawCompleteButton(_ sender: Any) {
        switch lineType {
        case LineType.FreeCurve,
             LineType.Eraser,
             LineType.ClosedCurve:
            break
        case LineType.Ellipse:
            if (canvas.isDrawing) {
                drawEllipseEnded()
            }
            break
        case LineType.Rectangle:
            if (canvas.isDrawing) {
                drawRectangleEnded()
            }
            break
        case LineType.Polygon:
            if (polygonStatus == .Moving || polygonStatus == .DrawStarted) {
                polygonStatus = .DrawStopping
                drawEnded_Polygon()
            }
            break
        }
    }
    
    // -----------------------------------------------------------------
    // 마크 색상 세그멘티드뷰 선택시
    // -----------------------------------------------------------------
    @IBAction func didTapLineColorSegmented(_ sender: Any) {
        lineColor = EnumDrawingColor(rawValue: lineColorSegmented.selectedSegmentIndex)!.color
        if (lineType == .Ellipse) {
            ellipseLayer.strokeColor = lineColor.cgColor
        }
        else if (lineType == .Rectangle) {
            rectangleLayer.strokeColor = lineColor.cgColor
        }
        else {
            polygonLayer.strokeColor = lineColor.cgColor
        }
        widthSliderViewSetNeedsDisplay()
    }
    
    // -----------------------------------------------------------------
    // 그리고 모드/자르기 모드 선택시
    // -----------------------------------------------------------------
    @IBAction func didTapCutModeSegmented(_ sender: Any) {
        if (cutModeSegmented.selectedSegmentIndex == 0) {
            isCutMode = false
        }
        else {
            isCutMode = true
        }
    }
    
    
    @IBAction func didTapClearImage(_ sender: Any) {
        if let sourceImage = UIImage(contentsOfFile: savedSourceImageUrlPath!) {
            EditingImage.image = sourceImage
            originalImage = sourceImage
            resetImageFilter()
        }
        ScrollImage.zoomScale = 1.0
        canvas.clear(exceptUndo:true)
        markCountLabel.text = "\(canvas.lines.count)개"

        undoredoEnable()
        EditingImage.isUserInteractionEnabled = true
        noticeClearMark = false
        
        // 마킹을 다시 하기 위하여 클리어되었으므로, 업로드 대상
        markUpdated = true
        
    }

    func arrowLeftClick(_ sender: Any? = nil) {

        let num = currentImageIndex - 1
        
        if (num < 0) {
            self.view.showToast(toastMessage: "처음 이미지 입니다.", duration: 0.5)
            return
        }

        arrowImage(num:num)
        animation(view: EditingImage, direction: .LeftToRight)
        animation(view: orgEditingImage, direction: .LeftToRight)

        return
    }
    

    func arrowRightClick(_ sender: Any? = nil) {

        let num = currentImageIndex + 1
        
        if (num > imageArray.count - 1) {
            self.view.showToast(toastMessage: "마지막 이미지 입니다.", duration: 0.5)
            return
        }

        arrowImage(num:num)
        animation(view: EditingImage, direction: .RightToLeft)
        animation(view: orgEditingImage, direction: .RightToLeft)

        return

    }
    
    // -----------------------------------------------------------------------------------------
    // 20200902
    // -----------------------------------------------------------------------------------------
    func arrowImageLastClick() {

        let num = imageArray.count - 1
        
        if (imageArray.count == 0 || currentImageIndex == num) {
            return
        }
        
        arrowImage(num: num)
        animation(view: orgEditingImage, direction: .RightToLeft)
        animation(view: EditingImage, direction: .RightToLeft)

        return
    }
    
    // -----------------------------------------------------------------------------------------
    // 20200902
    // -----------------------------------------------------------------------------------------
    func arrowImageFirstClick() {

        let num = 0
        
        if (imageArray.count == 0 || currentImageIndex == 0) {
            return
        }
        
        arrowImage(num:num)
        animation(view: orgEditingImage, direction: .LeftToRight)
        animation(view: EditingImage, direction: .LeftToRight)

        return
    }
    


    func arrowImage(num:Int) {
        
        if let befIndexPath = selectedMainImageCellIndexPath {
            if let befCell = collectionViewMainImage.cellForItem(at: befIndexPath) as? MainImageCell {
                if (imageArray[currentImageIndex].markNum! > 0) {
                    befCell.colorType(.marked)
                }
                else if (imageArray[currentImageIndex].isLabelingDone!) {
                    befCell.colorType(.marked)
                }
                else if (imageArray[currentImageIndex].isDrop! == "Y") {
                    befCell.colorType(.drop)
                }
                else {
                    befCell.colorType(.basic)
                }
            }
        }

        currentImageIndex = num
        
        let indexPath = IndexPath(item: currentImageIndex, section: 0)

        DispatchQueue.main.async {
            self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
            DoEvents(f: 0.01)

            let cell = self.collectionViewMainImage.cellForItem(at: indexPath) as! MainImageCell
            cell.colorType(.selected)
            self.selectedMainImageCellIndexPath = indexPath

        }
        
        loadImageFromURL(index: currentImageIndex)    // 이미지를 가져옴

    }
    
    // -----------------------------------------------------------------------------------------
    // 20200822 썸네일 이미지 맨 오른쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageLastClick() {

        let num = subImageArray.count - 1
        
        if (subImageArray.count == 0 || selectedSubImageRowNum == num) {
            return
        }
        
        arrowSubImage(num:num)
        animation(view: orgEditingImage, direction: .RightToLeft)
        animation(view: EditingImage, direction: .RightToLeft)

        return
    }
    
    // -----------------------------------------------------------------------------------------
    // 20200822 썸네일 이미지 맨 왼쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageFirstClick() {

        let num = 0
        
        if (subImageArray.count == 0 || selectedSubImageRowNum == 0) {
            return
        }
        
        arrowSubImage(num:num)
        animation(view: orgEditingImage, direction: .LeftToRight)
        animation(view: EditingImage, direction: .LeftToRight)

        return
    }
    

    // -----------------------------------------------------------------------------------------
    // 20200819 썸네일 이미지 오른쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageRightClick(_ sender: Any? = nil) {

        let num = selectedSubImageRowNum + 1
        
        if (num > subImageArray.count - 1) {
            self.view.showToast(toastMessage: "마지막 이미지 입니다.", duration: 0.5)
            return
        }

        arrowSubImage(num:num)
        animation(view: orgEditingImage, direction: .RightToLeft)
        animation(view: EditingImage, direction: .RightToLeft)

        return
    }
    
    // -----------------------------------------------------------------------------------------
    // 20200819 썸네일 이미지 왼쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageLeftClick(_ sender: Any? = nil) {

        let num = selectedSubImageRowNum - 1
        
        if (num < 0) {
            self.view.showToast(toastMessage: "처음 이미지 입니다.", duration: 0.5)
            return
        }
        
        arrowSubImage(num:num)
        animation(view: orgEditingImage, direction: .LeftToRight)
        animation(view: EditingImage, direction: .LeftToRight)

        return 

    }
    
    func arrowSubImage(num:Int) {

        if let befIndexPath = selectedThumbnailCellIndexPath {
            if let befCell = collectionViewThumbnail.cellForItem(at: befIndexPath) as? ThumbnailCell {
                if (subImageArray[selectedSubImageRowNum].mark_num! > 0) {
                    befCell.colorType(.marked)
                }
                else if (subImageArray[selectedSubImageRowNum].isLabelingDone!) {
                    befCell.colorType(.marked)
                }
                else {
                    befCell.colorType(.basic)
                }
            }
        }
        
        selectedSubImageRowNum = num
        let indexPath = IndexPath(item: selectedSubImageRowNum, section: 0)
        
        DispatchQueue.main.async {
            self.collectionViewThumbnail.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
            
            // 20200821 scrollitem을 실제 수행할 시간을 벌어줘야 함. 선택되어 있지 않는 쪽으로 스크롤을 한 후에 보이지 않는 것을 아래의 cellForItem을 하면 에러나기 때문
            DoEvents(f: 0.01)

            let cell = self.collectionViewThumbnail.cellForItem(at: indexPath) as! ThumbnailCell
            cell.colorType(.selected)
            self.selectedThumbnailCellIndexPath = indexPath

        }

        self.selectedThumbnailCellIndexPath = indexPath

        loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
        //resetWhenImageChanged()

    }
    
    //--------------------------------------------------------------------------------
    // 이미지를 보여줄때 애니메이션을 함 20200821
    //--------------------------------------------------------------------------------
    func animation(view: UIView, direction:AnimationDirection) {
        
        let x = view.frame.origin.x
        let y = view.frame.origin.y

        view.alpha = 0
        
        var duration = 0.15

        if direction == .LeftToRight {
            view.frame = CGRect(x: view.frame.origin.x - view.frame.width, y: view.frame.origin.y, width: view.frame.width, height: view.frame.height)
        }
        else if direction == .RightToLeft {
            view.frame = CGRect(x: view.frame.origin.x + view.frame.width, y: view.frame.origin.y, width: view.frame.width, height: view.frame.height)
        }
        else if direction == .TopToBottom {
            view.frame = CGRect(x: view.frame.origin.x, y: view.frame.origin.y - view.frame.height, width: view.frame.width, height: view.frame.height)
            duration = 0.2
        }
        else if direction == .BottomToTop {
            view.frame = CGRect(x: view.frame.origin.x, y: view.frame.origin.y + view.frame.height, width: view.frame.width, height: view.frame.height)
            duration = 0.2
        }

        UIView.animate(withDuration: duration, delay: 0, options: .curveEaseIn, animations: {
            view.frame = CGRect(x: x, y: y, width: view.frame.width, height: view.frame.height)
            view.alpha = 1
        }, completion: nil)
    }


    
    @IBAction func reloadClick(_ sender: Any) {
        if (imageArray.count == 0) { return }
        
        if (WorkingProjectMulti == "Y") {
            if (selectedSubImageRowNum >= 0 && selectedSubImageRowNum < subImageArray.count) {
                loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
                //resetWhenImageChanged()
            }
        }
        else {
            loadImageFromURL(index: currentImageIndex)
        }
        
    }


    // -----------------------------------------------------------------------------------------
    // 참조 이미지 정보 다운로드
    // -----------------------------------------------------------------------------------------
    //var referImageList:[String] = []
    var referImageList:ReferImageList = ReferImageList()
    var referImages:[UIImage] = []
    
    func showReferImageScreen() {

        let alertProgressNoAction = UIAlertController(title: "참조 이미지 다운로드 중...\n\n\n", message: nil, preferredStyle: .alert)
        let spinnerIndicator = UIActivityIndicatorView(style: .whiteLarge)
        spinnerIndicator.center = CGPoint(x: 135.0, y: 85.5)
        spinnerIndicator.color = UIColor.black
        spinnerIndicator.startAnimating()
        alertProgressNoAction.view.addSubview(spinnerIndicator)
        self.present(alertProgressNoAction, animated: false, completion: nil)
        
        DoEvents(f: 0.01)        // 그릴 시간을 줘야지~~~
        
        let success = getReferImageList()
        if (success) {
            loadReferImagesFromURL()
            alertProgressNoAction.dismiss(animated: false, completion: nil)
        }
        else {
            spinnerIndicator.removeFromSuperview()
            let otherAction = UIAlertAction(title: "OK", style: .default, handler: { action in
                alertProgressNoAction.dismiss(animated: true, completion: nil)
            })
            alertProgressNoAction.title = "메세지 확인\n\n\(LastURLErrorMessage)\n\n"
            alertProgressNoAction.addAction(otherAction)
            return
        }
        
        performSegue(withIdentifier: "segueReferImages", sender: nil)

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // -------------------------------------------------------------------------------
    // 네비게이션 BAR 블링크(blink) 처리
    // -------------------------------------------------------------------------------
    fileprivate var naviBarBlinkEndless = false
    fileprivate var naviBarBlinkRunning = false
    fileprivate var naviBarColor = UIColor.white

    func naviBarBlinkRunLoop() {
        
        self.naviBarBlinkRunning = true
        
        while (naviBarBlinkEndless) {

            if naviBarColor != UIColor.white {
                naviBarColor = UIColor.white
            }
            else {
                if (IsReviewMode) {
                    naviBarColor = UIColor.yellow
                }
                else {
                    naviBarColor = UIColor.white
                }
            }

            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.25) {
                    self.navigationController?.navigationBar.barTintColor = self.naviBarColor
                    self.navigationController?.navigationBar.layoutIfNeeded()
                }
            }
            
            Thread.sleep(forTimeInterval: 0.5)
        }
    }
    
    func naviBarBlinkStart() {
        
        if (naviBarBlinkRunning) {
            p("이미 title blink 프로세스가 동작중입니다.")
            return
        }
        
        DispatchQueue.global(qos: .background).async {
            p("title Blink Start")
            self.naviBarBlinkEndless = true
            self.naviBarBlinkRunLoop()
            DispatchQueue.main.async {
                p("title blink Stop")
                self.naviBarBlinkRunning = false
            }
        }
    }
    
    func naviBarBlinkStop() {
        if (!naviBarBlinkRunning) {
            p("이미 title blink 프로세스가 정지 상태입니다.")
            return
        }
        naviBarBlinkEndless = false
    }
    // -------------------------------------------------------------------------------


}

class DrawLineOnWidthSliderView: UIView {
    
    var lineColor:UIColor = UIColor.blue
    var lineWidth:CGFloat = 2.0

    override func draw(_ rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()
        context?.setLineWidth(lineWidth)
        context?.setStrokeColor(lineColor.cgColor)
        context?.setLineCap(.butt)
        context?.move(to: CGPoint(x:7, y: 35 + lineWidth / 2))
        context?.addLine(to: CGPoint(x: 82, y: 35 + lineWidth / 2))
        context?.strokePath()
    }
}
