//
//  LabelingVC_Struct.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020/09/01.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // ----------------------------------------------------------------------------------------------------------------------
    // 20200829 라베링 및 마크 실적 생성용
    // ----------------------------------------------------------------------------------------------------------------------
    struct LabelingResult: Codable {
        var target_cd: Int?
        var label_cd: Int?
    }
    
    struct Color: Codable {
        var R:CGFloat?
        var G:CGFloat?
        var B:CGFloat?
        var alpha:CGFloat?
        
        init(Red R:CGFloat, Green G:CGFloat, Blue B:CGFloat, alpha a:CGFloat) {
            self.R = R
            self.G = G
            self.B = B
            self.alpha = a
        }
    }
    
    struct MarkResult: Codable {
        var type:Int?
        var isClip:Bool?
        var width:CGFloat?
        var color:Color?
        var fillcolor:Color?
        var shape: [MyPoint] = []
    }
    
    struct RequestSaveLabelingResult: Codable {
        var proc_name: String?
        var project_cd: String?
        var user_id: String?
        var image_id: String?
        var multi_yn: String?
        var whole_yn: String?
        var sub_image_id: String?
        var labeling_ord: Int?
        var result: [LabelingResult] = []
        var mark_num: Int?
        var mark_result: [MarkResult] = []
    }

    struct MyBoundingBox : Codable {
        var x:Float?
        var y:Float?
        var w:Float?
        var h:Float?
    }

    struct MyPoint : Codable {
        var x:Int?
        var y:Int?
    }

}
