//
//  LabelingVC_Load_Thumbnail.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 24/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // --------------------------------------------------------------------------
    // 섬네일용 컬렉션뷰 기본 설정
    // --------------------------------------------------------------------------
    func setupImageCollectionView() {
        collectionViewThumbnail.delegate = self
        collectionViewThumbnail.dataSource = self
        collectionViewThumbnail.tag = 3
        
        if let layout = collectionViewThumbnail.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        
        collectionViewThumbnail.backgroundColor = UIColor.white
        //imageCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "ImageCell")
        
        imageCache.countLimit = 200
        imageCache.totalCostLimit = 0
    }
    
    // --------------------------------------------------------------------------
    // 섬네일용 이미지 로딩
    // --------------------------------------------------------------------------
    func loadSubImageList() {
        
        subImageList.removeAll()
        subImageArray.removeAll()
        selectedGroupIndex = -1
        
        //resetSubImageList()
        last_row_num = -1
        sub_image_count = 0
        selectedSubImageRowNum = -1
        
        WorkingSubImageIndex = 0    // 20200820
        
        if (getSubImageList()) {
            while (last_row_num >= 0 && last_row_num < sub_image_count) {
                if (getSubImageList()) {
                    continue
                }
                else {
                    p("error occur")
                }
            }
            
            //collectionViewThumbnail.reloadData() 20191008
            
            if (subImageList.count == 0) {
                self.view.showToast(toastMessage: "개별 이미지가 등록되어 있지 않습니다.", duration: 0.5)
                return
            }
            else {
                selectedGroupIndex = 0
                selectedGroupName = subImageList.groupList[0]
                collectionViewThumbGroup.reloadData()

                subImageArray = subImageList.imagesByGroup(group: selectedGroupName)
                collectionViewThumbnail.reloadData()

                setProgressValue()  // 20200820

                // selectedSubImageRowNum = 0

                // 20200820
                let foundIndex = subImageList.indexByImageId(imageId: LastLabelingSubImageId)
                if (foundIndex >= 0) {
                    WorkingSubImageIndex = ((foundIndex + 1) >= subImageList.count) ? foundIndex : foundIndex + 1
                }
                
                selectedSubImageRowNum = IsReviewMode ? subImageArray.count - 1 : WorkingSubImageIndex
                
                if (OrientationValue == .landscape) {
                    collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
                    DoEvents(f: 0.01)
                    // ------ 썸네일뷰를 가로 모드에서 좌측위치에 아래로 길게 배열하기 위해서는 아래를 풀고 위를 막음
                    //                collectionViewThumbnail.scrollToItem(at: IndexPath(item: centerItemNo, section: 0), at: UICollectionView.ScrollPosition.centeredVertically, animated: false)
                }
                else {
                    collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
                    DoEvents(f: 0.01)
                }
            }
        }
        else {
            if (LastURLErrorMessage.trimmingCharacters(in: [" "]) != "") {
                let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
                let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                    //self.dismiss(animated: true, completion: nil)
                    if (ResponseErrorCode == -90005 && LabelList.arrayLabelInfo.count == 0) {
                        self.loadLabelMasterWithResult()
                    }
                    alertProgressNoAction.dismiss(animated: true, completion: nil)
                })
                alertProgressNoAction.addAction(otherAction)
                self.present(alertProgressNoAction, animated: false, completion: nil)
            }
        }
        
    }
    
    func loadSubImageOneFromUrl(subImageInfo:SubImageInfo) {
        
        if (currentImageIndex < 0 || currentImageIndex >= imageArray.count) {
            p("Array Index Error : loadSubImageOneFromUrl() number \(currentImageIndex)")
            return
        }
        
        guard let sourceImageFullPath = imageArray[currentImageIndex].serverLocation,
            let subImageFullPath = subImageInfo.sub_server_location else { return }
        
        existImage = false
        noticeClearMark = false
        savedJsonFileUrlPath = nil
        
        savedSourceImageUrlPath = downloadSourceImage(subImageInfo.sub_image_id!, subImageFullPath)
        
        if let mark_num = subImageInfo.mark_num {
            loadedMarkNum = mark_num
            markCountLabel.text = "\(loadedMarkNum)개"
        }
        else {
            loadedMarkNum = 0
            markCountLabel.text = "0개"
        }

        //if (imageArray[currentImageIndex].isLabelingDone! && loadedMarkNum > 0) {
        if (subImageArray[selectedSubImageRowNum].isLabelingDone! && loadedMarkNum > 0) {          // 20200826

//            let markedLocation = getMarkedImagePathOnServer(sourceImageFullPathOnServer: sourceImageFullPath, sourceSubImageFullPathOnServer: subImageFullPath, sequence: 0)
//            savedMarkedImageUrlPath = downloadMarkedImage(subImageInfo.sub_image_id!, URL(fileURLWithPath: markedLocation.relativePath))
//
//            if savedMarkedImageUrlPath == nil {
//                if savedSourceImageUrlPath == nil {
//                    existImage = false
//                    realImage = #imageLiteral(resourceName: "ImageNotRegistered")                   // 디폴트 이미지 세팅
//                    showNotRegisterdMessage()
//                }
//                else {
//                    existImage = true
//                    //EditingImage.isUserInteractionEnabled = false
//                    noticeClearMark = true
//                    realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
//                }
//            }
//            else {
//                existImage = true
//                //EditingImage.isUserInteractionEnabled = false
//                noticeClearMark = true
//                realImage = UIImage(contentsOfFile: savedMarkedImageUrlPath!)
//            }
            
            existImage = true
            realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
            
            // 20200828 file 다운로드
            let jsonLocation = getJsonFilePathOnServer(sourceImageFullPathOnServer: sourceImageFullPath, sourceSubImageFullPathOnServer: subImageFullPath, sequence: 0)
            savedJsonFileUrlPath = downloadMarkedImage(subImageInfo.sub_image_id!, URL(fileURLWithPath: jsonLocation.relativePath))

        } // if절, 완료이미지
        else {
            if savedSourceImageUrlPath == nil {
                existImage = false
                realImage = #imageLiteral(resourceName: "ImageNotRegistered")                   // 디폴트 이미지 세팅
                showNotRegisterdMessage()
            }
            else {
                existImage = true
                realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
            }
        } // else 절, 미완료 이미지
        
        //realImageWHRatio = Float(realImage!.size.width / realImage!.size.height). 20201020 섬네일 막으면서 같이 막음
        EditingImage.image = realImage
        originalImage = realImage

        // 이미지 변경되었을때 관련된 오브젝트 리셋
        resetObjectsRelatedToLabeling()

        if (wholeSwitch.isOn) {
            loadLabelingResult(currentImageIndex)
        }
        else {
            loadSubImageLabelingResult(selectedSubImageRowNum)
        }

        resetWhenImageChanged()
        
        //imageIDLabel.text = imageId
        if let row_num = imageArray[currentImageIndex].row_num,
            let imageId = imageArray[currentImageIndex].id,
            let sub_row_num = subImageArray[selectedSubImageRowNum].row_num {
            imageIDLabel.text = "\(row_num)번(\(imageId))[\(sub_row_num)]"
        }
        else {
            imageIDLabel.text = " "
        }
        
        // 원본 이미지도 로드하자 20200818
        loadOrgSubImageOneFromUrl(subImageInfo: subImageInfo)
        
        // json 파일로부터 mark 좌표를 읽어서 그림. 20200831
        drawMarkAllFromJson()
        
        // 유저디폴트에 저장
        UserDefaults.standard.set(selectedSubImageRowNum, forKey: DefaultKey_SubImageIndex)     // 20200820
        WorkingSubImageIndex = selectedSubImageRowNum                                           // 20200820
        
        // 마지막 로딩했던 이미지를 저장
        UserDefaults.standard.set(subImageInfo.sub_image_id, forKey: DefaultKey_SubImageId)                   // 20200820
        WorkingSubImageId = subImageInfo.sub_image_id!                                                        // 20200820

        // 20200901 마크 타입 기본으로 설정
        lineTypeSegmented.selectedSegmentIndex = defaultLineType
        didTapLineTypeSegmented(lineTypeSegmented)

    }
    
    // -----------------------------------------------------------------------------
    // 원본 이미지 로드. 20200818
    // -----------------------------------------------------------------------------
    func loadOrgSubImageOneFromUrl(subImageInfo:SubImageInfo) {
        
        guard let orgSubImageFullPath = subImageInfo.org_file_path else { return }
        
        orgSavedSourceImageUrlPath = downloadSourceOrgImage(subImageInfo.sub_image_id!, orgSubImageFullPath)
        //orgEditingImage.image = UIImage(contentsOfFile: orgSavedSourceImageUrlPath!)
        if let temp = UIImage(contentsOfFile: orgSavedSourceImageUrlPath!) {
            orgEditingImage.image = temp.scaleImage(toSize: CGSize(width: 1920.0, height: 1080.0))
        }
        //orgEditingImage.image = resizeImage(image: temp!, targetSize: CGSize(width: 1920.0, height: 1080.0))
    }
    
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size

        let widthRatio  = targetSize.width  / image.size.width
        let heightRatio = targetSize.height / image.size.height

        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }

        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)

        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
    
    // -----------------------------------------------------------------------------
    // 서버 상의 마킹 이미지 저장 path 설정
    // 멀티레이어의 경우에는 source 이미지와 sub 이미지의 path 두개의 정보를 받음
    // -----------------------------------------------------------------------------
    func getMarkedImagePathOnServer(sourceImageFullPathOnServer:String, sourceSubImageFullPathOnServer:String, sequence:Int) -> URL {

// 20200826 막고 아래 1줄 추가
//        let sourceImageFullPathUrl = URL(fileURLWithPath: sourceImageFullPathOnServer)
//        var markedImageDirectroyUrl = sourceImageFullPathUrl.deletingLastPathComponent()                                    // 파일명 제거

        var markedImageDirectroyUrl = URL(fileURLWithPath: WorkingProjectImageDir)                                             // 20200826
        
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("marked")                                  // marked 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(WorkingLabelingOrder)")                 // 차수 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(imageArray[currentImageIndex].id!)")    // ImageID(멀티레이어 메인 ID) 추가
        
        let sourceSubImageFullPathUrl = URL(fileURLWithPath: sourceSubImageFullPathOnServer)
        let sourceSubImageNameUrl = sourceSubImageFullPathUrl.deletingPathExtension().lastPathComponent
        
        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@.jpg", sourceSubImageNameUrl, markedImageNameSuffix))  // 20200828
//        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@%03d.jpg", sourceSubImageNameUrl, markedImageNameSuffix, sequence))

        return markedImageFullPathUrl
    }
    
    // -----------------------------------------------------------------------------
    // 멀티 json 파일 경로 얻기 20200828
    // -----------------------------------------------------------------------------
    func getJsonFilePathOnServer(sourceImageFullPathOnServer:String, sourceSubImageFullPathOnServer:String, sequence:Int) -> URL {

        var markedImageDirectroyUrl = URL(fileURLWithPath: WorkingProjectImageDir)                                             // 20200826

        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("marked")                                  // marked 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(WorkingLabelingOrder)")                 // 차수 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(imageArray[currentImageIndex].id!)")    // ImageID(멀티레이어 메인 ID) 추가

        let sourceSubImageFullPathUrl = URL(fileURLWithPath: sourceSubImageFullPathOnServer)
        let sourceSubImageNameUrl = sourceSubImageFullPathUrl.deletingPathExtension().lastPathComponent

        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@.json", sourceSubImageNameUrl, markedImageNameSuffix))

        return markedImageFullPathUrl
    }

    // -----------------------------------------------------------------------------
    // 서버 상의 마킹 이미지 저장 path 설정
    // 싱글레이어의 경우에는 source 이미지 정보만 받음
    // -----------------------------------------------------------------------------
    func getMarkedImagePathOnServer(sourceImageFullPathOnServer:String, sequence:Int) -> URL {
        
        let sourceImageFullPathUrl = URL(fileURLWithPath: sourceImageFullPathOnServer)
        let sourceImageNameUrl = sourceImageFullPathUrl.deletingPathExtension().lastPathComponent

//        var markedImageDirectroyUrl = sourceImageFullPathUrl.deletingLastPathComponent()                                    // 파일명 제거
        var markedImageDirectroyUrl = URL(fileURLWithPath: WorkingProjectImageDir)                                          // 20200826

        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("marked")                                  // marked 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(WorkingLabelingOrder)")                 // 차수 추가
        
        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@.jpg", sourceImageNameUrl, markedImageNameSuffix))  //20200828
//        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@%03d.jpg", sourceImageNameUrl, markedImageNameSuffix, sequence))

        p(markedImageFullPathUrl.absoluteString)
        
        return markedImageFullPathUrl
    }
    
        // -----------------------------------------------------------------------------
        // 싱글 json 파일 경로 얻기 20200828
        // -----------------------------------------------------------------------------
        func getJsonFilePathOnServer(sourceImageFullPathOnServer:String, sequence:Int) -> URL {
            
            let sourceImageFullPathUrl = URL(fileURLWithPath: sourceImageFullPathOnServer)
            let sourceImageNameUrl = sourceImageFullPathUrl.deletingPathExtension().lastPathComponent

    //        var markedImageDirectroyUrl = sourceImageFullPathUrl.deletingLastPathComponent()                                    // 파일명 제거
            var markedImageDirectroyUrl = URL(fileURLWithPath: WorkingProjectImageDir)                                          // 20200826

            markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("marked")                                  // marked 추가
            markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
            markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(WorkingLabelingOrder)")                 // 차수 추가
            
            let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@.json", sourceImageNameUrl, markedImageNameSuffix))

            p(markedImageFullPathUrl.absoluteString)
            
            return markedImageFullPathUrl
        }


    func getMarkedImageDirectoryOnServer(serverSourceImagePath:String, imageId:String) -> URL {
        
//        let serverSourceImageURL = URL(fileURLWithPath: serverSourceImagePath)
//        let serverSourceImageDir = serverSourceImageURL.deletingLastPathComponent()             // 마지막 path를 제거
        
        let serverSourceImageDir = URL(fileURLWithPath: WorkingProjectImageDir)
        
        var serverMarkedImageDir = serverSourceImageDir.appendingPathComponent("marked")        // marked 추가
        serverMarkedImageDir = serverMarkedImageDir.appendingPathComponent(LoginID)             // 유저 추가
        serverMarkedImageDir = serverMarkedImageDir.appendingPathComponent("\(WorkingLabelingOrder)")   // 차수 추가
        if (WorkingProjectMulti == "Y") {
            serverMarkedImageDir = serverMarkedImageDir.appendingPathComponent("\(imageId)")    // 멀티일 경우에는 imageid 디렉토리를 추가
        }
        p(serverMarkedImageDir.absoluteString)
        return serverMarkedImageDir
    }
    
}
