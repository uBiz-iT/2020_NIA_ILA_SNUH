//
//  LabelingVC_Load.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 03/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    // ------------------------------------------------------------------------------
    // loadData()
    // ------------------------------------------------------------------------------
    func loadData() {
        if (isWorking) {
            
            checkSwipeGesture(Mark_YN: WorkingProjectMark)      // 20200902 mark가 아닌 경우에는 swipe 허용
            
            projectNameLabel.text = WorkingProjectName
            //labelingOrderLabel.text = String(format: "%d", WorkingLabelingOrder)
            labelingOrderLabel.text = "\(WorkingLabelingOrder)차"
            
            if (loadLabelMaster()) {
                loadImageList()
            }
        }
    }
    
    // ------------------------------------------------------------------------------
    // 해당 프로젝트에 해당하는 라벨 목록 로드
    // ------------------------------------------------------------------------------
    func loadLabelMaster() -> Bool {

        LabelList.arrayLabelInfo.removeAll()

        if (selectLabelList()) {
            if (LabelList.arrayLabelInfo.count == 0) {
                self.view.showToast(toastMessage: "프로젝트에 해당하는 라벨이 없습니다.", duration: 1.1)
            }
            tableViewLabelLeft.reloadData()
            tableViewLabelRight.reloadData()
            collectionViewBottom.reloadData()
            return true
        }
        else {
            self.view.showToast(toastMessage: "에러 메세지\r\n\r\n\(LastURLErrorMessage)\r\n", duration: 1.5)
            return false
        }
        
    }
 
    // ------------------------------------------------------------------------------
    // 해당 프로젝트에 해당하는 이미지 목록 로드
    // ------------------------------------------------------------------------------
    func loadImageList() {
        
        resetObjectsRelatedToLabeling()
        canvas.clear()
        markCountLabel.text = "0개"
        
        undoredoEnable()
        currentImageIndex = -1
        
        let temp = isTotalExplore
        
        //isTotalExploreSwitch.setOn(true, animated: false)
        
        FPNLFlag = "C"
        
        mainImageList.removeAll()
        image_last_row_num = 0
        image_count = 0

        if (selectImageList()) {

            while (image_last_row_num >= 0 && image_last_row_num < image_count) {
                if (selectImageList()) {
                    continue
                }
                else {
                    p("error occur")
                }
            }
            
            if (mainImageList.count == 0) {
                self.view.showToast(toastMessage: "이미지가 등록되어 있지 않습니다.", duration: 1.5)
                return
            }
            
            imageArray = IsReviewMode ? mainImageList.doneImagesByResult(leftValue: LeftIndexOnReviewMode, rightValue: RightIndexOnReviewMode) : mainImageList.images
            collectionViewMainImage.reloadData()
            
            setProgressValue()
            
            if (imageArray.count == 0) {
                self.view.showToast(toastMessage: "해당하는 이미지가 없습니다.", duration: 1.5)
            }
            else {
                //if (isFromProjectMenu || isFromLoginMenu) {
                    let foundIndex = mainImageList.indexByImageId(imageId: LastLabelingImageId)
                    if (foundIndex >= 0) {
                        WorkingImageIndex = foundIndex
                        //WorkingImageIndex = ((foundIndex + 1) >= mainImageList.count) ? foundIndex : foundIndex + 1
                    }
                    //p("foundIndex : \(foundIndex), \(WorkingImageId)")
                //}
                currentImageIndex = IsReviewMode ? imageArray.count - 1 : WorkingImageIndex
                
                //p("currentImageIndex : ", currentImageIndex)

                if (currentImageIndex >= 0 && currentImageIndex < imageArray.count) {
                    let indexPath = IndexPath(item: currentImageIndex, section: 0)
                    DispatchQueue.main.async {
                        self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
                        DoEvents(f: 0.01)
                    }
                    
                    loadImageFromURL(index: currentImageIndex)    // 이미지를 가져옴
                }
                else {
                    p("Array Index Error : loadImageList() number \(currentImageIndex)")
                }
            }
        }
        else {
            if (LastURLErrorMessage.trimmingCharacters(in: [" "]) != "") {
                let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
                let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                    //self.dismiss(animated: true, completion: nil)
                    if (ResponseErrorCode == -90005 && LabelList.arrayLabelInfo.count == 0) {
                        self.loadLabelMasterWithResult()
                    }
                    alertProgressNoAction.dismiss(animated: true, completion: nil)
                })
                alertProgressNoAction.addAction(otherAction)
                self.present(alertProgressNoAction, animated: false, completion: nil)
            }
        }
        checkHiddenView()
        
        isTotalExplore = temp
        
    }
 
    // -----------------------------------------------------------------------------
    // 라벨별 라벨링 수량을 포함한 라벨 마스터 로딩
    // -----------------------------------------------------------------------------
    func loadLabelMasterWithResult() {
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        DoEvents(f: 0.01)
        
        if (!selectLabelListWithResult()) {
            p("selectLabelListWithResult() call error")
        }
        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
    }
    
    // -----------------------------------------------------------------------------
    // 기존의 라벨링 결과를 좌우측 라벨링 테이블뷰에 리프레쉬하고 선택된 인덱스 변수에 대입
    // -----------------------------------------------------------------------------
    func loadLabelingResult(_ currentImageIndex:Int) {
        if (currentImageIndex < 0 || currentImageIndex >= imageArray.count) {
            p("Array Index Error : loadLabelingResult() number \(currentImageIndex)")
            return
        }
        
        for item in imageArray[currentImageIndex].labelingResult {
            if (item.target_cd == 0) {
                //selectedLabelLeftIndex = item.label_cd!
                selectedLabelLeftIndex = LabelList.getIndexOfLabelCode(location: 0, labelCode: item.label_cd!)
            }
            else if (item.target_cd == 1) {
                //selectedLabelRightIndex = item.label_cd!
                selectedLabelRightIndex = LabelList.getIndexOfLabelCode(location: 1, labelCode: item.label_cd!)
            }
        }
        
        tableViewLabelLeft.reloadData()
        tableViewLabelRight.reloadData()
        collectionViewBottom.reloadData()
        
        checkSaveButtonShow()
    }

    // -----------------------------------------------------------------------------
    // 기존의 라벨링 결과를 좌우측 라벨링 테이블뷰에 리프레쉬하고 선택된 인덱스 변수에 대입.. sub 이미지에 대한 라벨링 결과 20200820
    // -----------------------------------------------------------------------------
    func loadSubImageLabelingResult(_ currentImageIndex:Int) {
        if (currentImageIndex < 0 || currentImageIndex >= subImageArray.count) {
            p("Array Index Error : loadSubImageLabelingResult() number \(currentImageIndex)")
            return
        }
        
        for item in subImageArray[currentImageIndex].labelingResult {
            if (item.target_cd == 0) {
                //selectedLabelLeftIndex = item.label_cd!
                selectedLabelLeftIndex = LabelList.getIndexOfLabelCode(location: 0, labelCode: item.label_cd!)
            }
            else if (item.target_cd == 1) {
                //selectedLabelRightIndex = item.label_cd!
                selectedLabelRightIndex = LabelList.getIndexOfLabelCode(location: 1, labelCode: item.label_cd!)
            }
        }
        
        tableViewLabelLeft.reloadData()
        tableViewLabelRight.reloadData()
        collectionViewBottom.reloadData()
        
        checkSaveButtonShow()
    }


    // ------------------------------------------------------------------------------
    // 해당하는 인덱스(이미지 순서)에 해당하는 이미지를 서버로부터 로딩
    // ------------------------------------------------------------------------------
    func loadImageFromURL(index:Int) {
        
        resetSubImageList()
        
        let imageId = imageArray[index].id
        genderLabel.text = imageArray[index].sex

        // 멀티레이어의 경우에는 멀티레이어 이미지를 가져온다
        if (WorkingProjectMulti == "Y") {
            
            // ------------------------------------------------
            // 스피너 시작
            // ------------------------------------------------
            let child = SpinnerViewController()
            child.view.frame = view.frame
            view.addSubview(child.view)
            child.didMove(toParent: self)
            DoEvents(f: 0.01)
            
            loadSubImageList()
            
            // ------------------------------------------------
            // 스피너 종료
            // ------------------------------------------------
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()

            if (selectedSubImageRowNum >= 0 && selectedSubImageRowNum < subImageArray.count) {
                loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
            }
            
        }
        else {

            existImage = false
            noticeClearMark = false
            savedJsonFileUrlPath = nil

            guard let file_name = imageArray[index].serverLocation else { return }
            
            savedSourceImageUrlPath = downloadSourceImage(imageArray[index].id!, file_name)
            
            if (imageArray[index].isLabelingDone! && imageArray[index].markNum! > 0) {
                
//                let markedLocation = getMarkedImagePathOnServer(sourceImageFullPathOnServer: file_name, sequence: 0)
//                savedMarkedImageUrlPath = downloadMarkedImage(imageArray[index].id!, URL(fileURLWithPath: markedLocation.relativePath))
//
//                if savedMarkedImageUrlPath == nil {
//                    if savedSourceImageUrlPath == nil {
//                        existImage = false
//                        realImage = #imageLiteral(resourceName: "ImageNotRegistered")                   // 디폴트 이미지 세팅
//                        showNotRegisterdMessage()
//                    }
//                    else {
//                        existImage = true
//                        //EditingImage.isUserInteractionEnabled = false
//                        noticeClearMark = true
//                        realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
//                    }
//
//                }
//                else {
//                    existImage = true
//                    //EditingImage.isUserInteractionEnabled = false
//                    noticeClearMark = true
//                    realImage = UIImage(contentsOfFile: savedMarkedImageUrlPath!)
//                }
                
                existImage = true
                realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)

                // 20200828 file 다운로드
                let jsonLocation = getJsonFilePathOnServer(sourceImageFullPathOnServer: file_name, sequence: 0)
                savedJsonFileUrlPath = downloadMarkedImage(imageArray[index].id!, URL(fileURLWithPath: jsonLocation.relativePath))


            } // if절, 완료이미지
            else {
                if savedSourceImageUrlPath == nil {
                    existImage = false
                    realImage = #imageLiteral(resourceName: "ImageNotRegistered")                   // 디폴트 이미지 세팅
                    showNotRegisterdMessage()
                }
                else {
                    existImage = true
                    realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
                }
            } // else 절, 미완료 이미지

            realImageWHRatio = Float(realImage!.size.width / realImage!.size.height)
            //p("Image real size : ", realImage!.size.width, ",", realImage!.size.height, ",", realImageWHRatio!)
            EditingImage.image = realImage
            originalImage = realImage
            
            loadOrgImageFromURL(index: index)           // 20200819
            
            // 이미지 변경되었을때 관련된 오브젝트 리셋
            resetObjectsRelatedToLabeling()

            loadLabelingResult(index)

            resetWhenImageChanged()

            //imageIDLabel.text = imageId
            if let row_num = imageArray[index].row_num {
                imageIDLabel.text = "\(row_num)번(\(imageId!))"
            }
            else {
                imageIDLabel.text = " "
            }
            
            // json 파일로부터 mark 좌표를 읽어서 그림. 20200829
            drawMarkAllFromJson()
            
            // 20200830 drawMarkAll 아래로 이동
            loadedMarkNum = imageArray[currentImageIndex].markNum!
            markCountLabel.text = "\(imageArray[index].markNum!)개"
            
        } // else 절, 싱글레이어

        checkHiddenView()

        // 유저디폴트에 저장
        UserDefaults.standard.set(index, forKey: DefaultKey_ImageIndex)
        WorkingImageIndex = index
        
        if (IsReviewMode) {
            WorkingImageIdOnReviewMode = imageId!
        }
        else {
            // 마지막 로딩했던 이미지를 저장
            UserDefaults.standard.set(imageId, forKey: DefaultKey_ImageId)
            WorkingImageId = imageId!
        }
        
        // 20200830 그리기를 기본값으로 설정
        lineTypeSegmented.selectedSegmentIndex = defaultLineType
        didTapLineTypeSegmented(lineTypeSegmented)
        
    }
    
    // -----------------------------------------------------------------------------
    // JSON 파일 읽어서 다시 그리기
    // -----------------------------------------------------------------------------
    func drawMarkAllFromJson() {
        
        if savedJsonFileUrlPath != nil {

            canvas.clear()
            
            let url = URL(fileURLWithPath: savedJsonFileUrlPath!)

            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let result = try decoder.decode(RequestSaveLabelingResult.self, from: data)
                
                //p(result.mark_result)
                
                canvas.clear()
                
                result.mark_result.forEach { (mark) in
                    var lineType:LineType
                    var lineColor:UIColor
                    var fillColor:UIColor
                    var width:CGFloat
                    var alpha:CGFloat
                    var isClip:Bool
                    if let tNum = mark.type {
                        if let t = LineType(rawValue: tNum) {
                            lineType = t
                        }
                        else {
                            lineType = .ClosedCurve
                        }
                    }
                    else {
                        lineType = .ClosedCurve
                    }
                    if let r = mark.color?.R,
                        let g = mark.color?.G,
                        let b = mark.color?.B,
                        let a = mark.color?.alpha {
                        lineColor = UIColor(red: r, green: g, blue: b, alpha: 1)
                        alpha = a
                    }
                    else {
                        lineColor = .red
                        alpha = 0
                    }
                    if let r = mark.fillcolor?.R,
                       let g = mark.fillcolor?.G,
                       let b = mark.fillcolor?.B {
                        fillColor = UIColor(red: r, green: g, blue: b, alpha: 1)
                    }
                    else {
                        fillColor = .clear
                    }
                    if let w = mark.width {
                        width = w
                    }
                    else {
                        width = 2
                    }
                    if let c = mark.isClip {
                        isClip = c
                    }
                    else {
                        isClip = false
                    }
                    var line = Line(isClip: isClip, type: lineType, width: width, color: lineColor, fillcolor: fillColor, alpha: alpha,
                                    points: getScreenPoints(myPoints: setMyPoints(myPoints: mark.shape)), realPoints: [])
                    
                    line.realPoints = getRealPoints(screenPoints: line.points)
                    
                    canvas.append(line: line)
                    canvas.setNeedsDisplay()
                    undoButton.isEnabled = true
                }
                
                imageArray[currentImageIndex].markNum = result.mark_result.count
                                
            } catch {
                print("error:\(error)")
            }
            
        }
    }
    
    // -----------------------------------------------------------------------------
    // 가로세로 다시 그리기
    // -----------------------------------------------------------------------------
    func redrawMarkAll() {
        
        if canvas.lines.count > 0 {
            ScrollImage.zoomScale = 1.0
            for (index, line) in canvas.lines.enumerated() {
               canvas.lines[index].points = getScreenPoints(myPoints: line.realPoints)
            }
            canvas.setNeedsDisplay()
        }

    }

    
    // -----------------------------------------------------------------------------
    // 원본 이미지 불러오기       20200819
    // -----------------------------------------------------------------------------
    func loadOrgImageFromURL(index:Int) {
        guard let orgImageId = imageArray[index].id,
            let orgImageFullPath = imageArray[index].org_file_path else { return }
        
        if orgImageFullPath == "<SUB>" { return }
        
        orgSavedSourceImageUrlPath = downloadSourceOrgImage(orgImageId, orgImageFullPath)
        //orgEditingImage.image = UIImage(contentsOfFile: orgSavedSourceImageUrlPath!)
        
        if let temp = UIImage(contentsOfFile: orgSavedSourceImageUrlPath!) {
            orgEditingImage.image = temp.scaleImage(toSize: CGSize(width: 1920.0, height: 1080.0))
        }

    }
        
    func setLabelTouchEnable(enable:Bool) {
        tableViewLabelLeft.allowsSelection = enable
        tableViewLabelRight.allowsSelection = enable
        collectionViewBottom.allowsSelection = enable
    }

    // -----------------------------------------------------------------------------
    // 섬네일 이미지를 훵하지 않게 뭐라도 보여주자
    // -----------------------------------------------------------------------------
    func resetSubImageList() {
        subImageList.removeAll()
        for i in 0...20 {
            let subImageInfo = SubImageInfo()
            subImageInfo.row_num = i
            subImageInfo.mark_num = 0
            subImageInfo.group = "default"
            subImageInfo.newMarking = false
            subImageInfo.isLabelingDone = false     // 20200819
            subImageInfo.newMarkedImage = nil
            subImageInfo.sub_image_id = "\(i)"
            subImageInfo.sub_server_location = nil
            subImageList.append(subImageInfo: subImageInfo)
        }
        subImageArray = subImageList.imagesByGroup(group: "default")
        collectionViewThumbnail.reloadData()
    }
    
    func resetWhenImageChanged() {
        markUpdated = false
        ScrollImage.zoomScale = 1
        orgScrollImage.zoomScale = 1                                // 20200814
        EditingImage.isUserInteractionEnabled = true
        orgEditingImage.isUserInteractionEnabled = true             // 20200814
        canvas.clear()
        
        EditingImage.contentMode = .scaleAspectFit
        orgEditingImage.contentMode = .scaleAspectFit
        
        resetImageFilter()
        
        undoredoEnable()
    }
    
    // ------------------------------------------------------------------------------
    // 서버로부터 참조 이미지의 실제 이미지 가져오기
    // ------------------------------------------------------------------------------
    func loadReferImagesFromURL() {
        
        referImages.removeAll()

        for imageInfo in referImageList.images {
            if let imageUrl = imageInfo.imageUrl {
                let encoded = imageUrl.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
                let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
                if let data = try? Data(contentsOf: url!) {
                    referImages.append(UIImage(data: data)!)
                }
                else {
                    p("image file name " + imageUrl + "download error")
                }
            }
        }

        // 메인이미지 나중에 추가
        if savedSourceImageUrlPath != nil {
            if let sourceImage = UIImage(contentsOfFile: savedSourceImageUrlPath!) {
                referImages.append(sourceImage)
            }
        }
        if (WorkingProjectMulti == "Y") {
            referImageList.append(group: "NotDefinedGroup", imageUrl: subImageArray[selectedSubImageRowNum].sub_server_location!)
        }
        else {
            referImageList.append(group: "NotDefinedGroup", imageUrl: imageArray[currentImageIndex].serverLocation!)
        }
        
    }
    

}
