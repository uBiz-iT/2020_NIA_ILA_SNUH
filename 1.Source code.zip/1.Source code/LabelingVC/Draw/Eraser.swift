//
//  Eraser.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 21/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func panGestureBegan_Eraser(point:CGPoint) {
        befErasingPoint = point
        if (canvas.isDrawing) { return }
        canvas.isDrawing = true                                         // 지우기 시작
    }
    
    func panGestureMoved_Eraser(point:CGPoint) {
        
        if (!canvas.isDrawing) { return }                               // 지우기 시작 상태가 아니면 return
        if (canvas.lines.count <= 0) { return }
        
        var isRemoved = false
        for (index, line) in canvas.lines.enumerated() {
            
            switch line.type {
            case LineType.Ellipse :
                let pointx = line.points[0].x
                let pointy = line.points[0].y
                let width = line.points[1].x - line.points[0].x
                let height = line.points[2].y - line.points[1].y
                // 타원 정의
                let rect = CGRect(x: pointx, y: pointy, width: width, height: height)
                if (containsInEllipse(frame: rect, point: point)) {
                    canvas.remove(index)
                    p("ellipse erasing~~~~")
                    undoredoEnable()
                    isRemoved = true
                }
                //break
            case LineType.Rectangle :
                let pointx = line.points[0].x
                let pointy = line.points[0].y
                let width = line.points[1].x - line.points[0].x
                let height = line.points[2].y - line.points[1].y
                // 타원 정의
                let rect = CGRect(x: pointx, y: pointy, width: width, height: height)
                if (containsInRectangle(frame: rect, point: point)) {
                    canvas.remove(index)
                    p("rectangle erasing~~~~")
                    undoredoEnable()
                    isRemoved = true
                }
            case LineType.Polygon :
                
                if (line.points.count == 2) {
                    if (isCrossWithSomeLine(points: line.points, point1: befErasingPoint!, point2: point)) {
                        canvas.remove(index)
                        p("polygon erasing~~~~")
                        undoredoEnable()
                        isRemoved = true
                    }
                }
                // 꼭지점이 3개 이상이면 다각형 내부에 존재하는지 체크
                else {
                    if (containsInPolygon(points: line.points, point: point)) {
                        canvas.remove(index)
                        p("polygon erasing~~~~")
                        undoredoEnable()
                        isRemoved = true
                    }
                }
            case LineType.FreeCurve :
                if (isCrossWithSomeLine(points: line.points, point1: befErasingPoint!, point2: point)) {
                    p("free erasing remove begin : ", index)
                    canvas.remove(index)
                    p("free erasing remove end   : ", index)
                    undoredoEnable()
                    isRemoved = true
                }
            case LineType.ClosedCurve :
                if (containsInPolygon(points: line.points, point: point)) {
                    canvas.remove(index)
                    p("closed erasing~~~~")
                    undoredoEnable()
                    isRemoved = true
                }
                break
            default:
                ()
            }
            
            if (isRemoved) {
                markCountLabel.text = "\(canvas.lines.count)개"
                if (canvas.lines.count > 0) {
                    markUpdated = true
                }
                break
            }
        }
        
        befErasingPoint = point
        
    }
    
    func panGestureEnded_Eraser(point:CGPoint) {
        if (!canvas.isDrawing) { return }                               // 지우기 시작 상태가 아니면 return
        canvas.isDrawing = false                                        // 지우기 상태 해제
    }
    
    func undoredoEnable() {
        undoButton.isEnabled = canvas.lines.count > 0 ? true : false
        redoButton.isEnabled = canvas.undoCount > 0 ? true : false
    }
    
}
