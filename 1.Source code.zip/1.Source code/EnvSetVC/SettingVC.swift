//
//  SettingVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 25/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class SettingVC: UITableViewController {

    @IBOutlet var tintColorSegmentedControl: UISegmentedControl!
    @IBOutlet var orientationSegmentedControl: UISegmentedControl!

    @IBOutlet var currentVersion: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        initVariables()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        SetOrientation()
        
        // 1 touch 2 taps
        let doubleTapGesture = UIShortTapGestureRecognizer(target: self, action: #selector(doubleTapped(_:)))
        doubleTapGesture.numberOfTouchesRequired = 2
        doubleTapGesture.numberOfTapsRequired = 2
        self.view.addGestureRecognizer(doubleTapGesture)
    }
    
    func initVariables() {
        
        //---------------------------------------------------------------------------
        // orientation segmented control
        //---------------------------------------------------------------------------
        orientationSegmentedControl.removeAllSegments()
        for item in EnumOrientation.allCases {
            let title = EnumOrientation(rawValue: item.rawValue)?.title
            orientationSegmentedControl.insertSegment(withTitle: title, at: orientationSegmentedControl.numberOfSegments, animated: false)
        }
        
        //---------------------------------------------------------------------------
        // tint color segmented control
        //---------------------------------------------------------------------------
        tintColorSegmentedControl.removeAllSegments()
        for item in EnumTintColor.allCases {
            let title = EnumTintColor(rawValue: item.rawValue)?.title
            let color = EnumTintColor(rawValue: item.rawValue)?.color
            let index = tintColorSegmentedControl.numberOfSegments
            tintColorSegmentedControl.insertSegment(withTitle: title, at: index, animated: false)
            (tintColorSegmentedControl.subviews[index] as UIView).tintColor = color
        }
        
        //---------------------------------------------------------------------------
        // 저장된 orientation 가져오기. 없으면 nil이 아닌 0을 return 받음
        //---------------------------------------------------------------------------
        let userDefaultOrientation = UserDefaults.standard.integer(forKey: OrientationKey)
        orientationSegmentedControl.selectedSegmentIndex = userDefaultOrientation
        
        //---------------------------------------------------------------------------
        // 저장된 tintColor index값 가져오기. 없으면 nil이 아닌 0을 return 받음
        //---------------------------------------------------------------------------
        let userDefaultTintColor = UserDefaults.standard.integer(forKey: TintColorKey)
        tintColorSegmentedControl.selectedSegmentIndex = userDefaultTintColor

        
        currentVersion.text = version
        
    }
    
    var version: String? {
        guard let dictionary = Bundle.main.infoDictionary,
            let version = dictionary["CFBundleShortVersionString"] as? String,
            let build = dictionary["CFBundleVersion"] as? String else {return nil}
        
        let versionAndBuild: String = "vserion: \(version), build: \(build)"
        return versionAndBuild
    }


    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        }
        else if section == 1 {
            return 2
        }
        return 0
    }

    @IBAction func orientationChanged(_ sender: Any) {
        let selectedIndex = orientationSegmentedControl.selectedSegmentIndex
        UserDefaults.standard.set(selectedIndex, forKey: OrientationKey)
        guard let changedOrientation = EnumOrientation(rawValue: selectedIndex)?.orientation else {
            return
        }
        OrientationValue = changedOrientation
    }
    
    @IBAction func tintColorChanged(_ sender: Any) {
        let selectedIndex = tintColorSegmentedControl.selectedSegmentIndex
        UserDefaults.standard.set(selectedIndex, forKey: TintColorKey)
        guard let changedColor = EnumTintColor(rawValue: selectedIndex)?.color else {
            return
        }
        SetTintColor(color: changedColor)
    }
    
    @objc func doubleTapped(_ gesture: UITapGestureRecognizer) {
        
        for window in UIApplication.shared.windows {
            if let window = window as? FingerTips {
                window.alwaysShowTouches = !window.alwaysShowTouches
                p("alwaysShowTouches value: ", window.alwaysShowTouches)
                if window.alwaysShowTouches {
                    self.view.showToast(toastMessage: "탭 위치 표시 모드입니다.", duration: 1.0)
                }
                else {
                    self.view.showToast(toastMessage: "탭 위치 표시 모드가 해제되었습니다.", duration: 1.0)
                }
                break
            }
        }

    }
    

}
