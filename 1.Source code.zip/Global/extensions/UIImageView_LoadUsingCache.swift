//
//  UIImageView_LoadUsingCache.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// --------------------------------------------------------------------------
// url로부터 이미지 로드 및 캐시 이용
// --------------------------------------------------------------------------
let imageCache = NSCache<AnyObject, AnyObject>()

extension UIImageView {
    func loadImageUsingUrlString(urlString: String) {
        
        //p("loadImageUsingUrlString : \(urlString)")
        
        let url = URL(string: urlString)
        
        image = nil
        
        if let imageFromCache = imageCache.object(forKey: urlString as AnyObject) as? UIImage {
            //DispatchQueue.main.async {
            self.image = imageFromCache
            //p("imageFromCache : \(urlString)")
            return
            //}
        }
        
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if error != nil {
                p(error!)
                return
            }
            DispatchQueue.main.async {
                let imageToCache = UIImage(data: data!)
                if let img = imageToCache {
                    imageCache.setObject(img, forKey: urlString as AnyObject)
                    self.image = img
                }
                else {
                    p("downloaded image url error : \(urlString)")
                    self.image = nil
                }
            }
            }.resume()
    }
}

