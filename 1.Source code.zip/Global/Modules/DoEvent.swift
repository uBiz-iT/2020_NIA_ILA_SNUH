//
//  DoEvent.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

func DoEvents(f: Float) {
    RunLoop.current.run(until: Date(timeIntervalSinceNow: TimeInterval(f)))
}

