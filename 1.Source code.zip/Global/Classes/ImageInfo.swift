//
//  ImageInfo.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

var mainImageList:ImageList = ImageList()

class ImageList {
    var images:[ImageInfo] = [ImageInfo]()
    var count:Int {
        get {
            return images.count
        }
    }
    
    // index가져오기
    func indexByImageId(imageId:String) -> Int {
        var retval = -1
        for (index, image) in images.enumerated() {
            if (image.id == imageId) {
                retval = index
                break
            }
        }
        return retval
    }
    
    // 라벨링 결과 라벨별 카운팅
    func countByLabel(target_cd:Int, label_cd:Int) -> Int {
        var count = 0
        for image in images {
            for result in image.labelingResult {
                if (result.target_cd == target_cd &&
                    result.label_cd == label_cd) {
                    count = count + 1
                }
            }
        }
        return count
    }
    
    // 라벨링 완료한 이미지만 가져오기
    func doneImages() -> [ImageInfo] {
        var imageInfoList: [ImageInfo] = []
        for image in images {
            if (image.isLabelingDone!) {
                imageInfoList.append(image)
            }
        }
        return imageInfoList
    }
    
    func doneImagesByResult(leftValue:Int, rightValue:Int) -> [ImageInfo] {
        var imageInfoList: [ImageInfo] = []
        var leftOK = false
        var rightOK = false
        
        for image in images {
            if (image.isLabelingDone!) {
                leftOK = false
                rightOK = false
                for result in image.labelingResult {
                    if (result.target_cd == 0) {
                        if (leftValue < 0 || result.label_cd == leftValue) {
                            leftOK = true
                        }
                    }
                    else if (result.target_cd == 1) {
                        if (rightValue < 0 || result.label_cd == rightValue) {
                            rightOK = true
                        }
                    }
                }
                if (leftOK && rightOK) {
                    imageInfoList.append(image)
                }
            }
        }
        return imageInfoList
    }
    
    // 이미지 정보 추가
    func append(imageInfo:ImageInfo) {
        images.append(imageInfo)
    }
    
    // 이미지 정보 목록 추가
    func append(imageList:[ImageInfo]) {
        images.append(contentsOf: imageList)
    }
    
    func removeAll() {
        images.removeAll()
    }
    
}

class ImageInfo {
    var row_num:Int?                                   // row num
    var id:String?                                     // image ID
    var serverLocation:String?                         // 이미지 파일 서버 위치
    var org_file_path:String?                          // 원본 이미지 파일 서버 위치
    var thu_file_path:String?                          // 썸네일 파일 서버 위치
    var sub_serverLocation:String?                     // 이미지 파일 서버 위치
    var name:String?                                   // 이름
    var age:Float?                                     // 나이
    var sex:String?                                    // 성별
    var birth:String?                                  // 생년
    var isDrop:String?                                 // Drop 여부
    var isLabelingDone:Bool?                           // 라벨링 여부
    var markNum:Int?                                   // 마크 수량
    var labelingResult:[LabelingLocationResult] = []   // 라벨링 결과
    var newMarking:Bool?
    var newMarkedImage:UIImage?
}

