//
//  LabelingVC_ImageOrg.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020/08/14.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//  20200814

import UIKit

extension LabelingVC {
    //-------------------------------------------------------------------------------------
    // ScrollImage : 이미지의 확대/축소/확대된 이미지 이동 등을 위하여 사용, 이미지를 scroll view 안에서 사용
    //-------------------------------------------------------------------------------------
    func setOrgScrollViewPropertyForImage() {
        orgScrollImage.contentSize = orgEditingImage.bounds.size
        orgScrollImage.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        
        orgScrollImage.alwaysBounceVertical = false
        orgScrollImage.alwaysBounceHorizontal = false
        orgScrollImage.showsVerticalScrollIndicator = true
        orgScrollImage.flashScrollIndicators()
        
        // 최소 터치수를 최소2개, 최대2개로 설정
        // 싱글터치는 이미지 자체 Pan 이벤트로 사용함.(mark용도로)
        orgScrollImage.panGestureRecognizer.minimumNumberOfTouches = 2
        orgScrollImage.panGestureRecognizer.maximumNumberOfTouches = 2
        setOrgImageZoomScaleInScrollView()
    }
    
    func setOrgImageZoomScaleInScrollView() {
        let imageViewSize = orgEditingImage.bounds.size
        let scrollViewSize = orgScrollImage.bounds.size
        let widthScale = scrollViewSize.width / imageViewSize.width
        let heightScale = scrollViewSize.height / imageViewSize.height
        
        orgScrollImage.minimumZoomScale = min(widthScale, heightScale)
        orgScrollImage.maximumZoomScale = orgScrollImage.minimumZoomScale * 5.0
    }
    
    func downloadOrgSourceImage(_ imageId:String, _ file_name:String) -> String? {

        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
        if let data = try? Data(contentsOf: url!) {
            
            let f = imageId + ".jpg"
            
            if (!makeDir(fullPath: orgSourceImageDirectoryURL!.path)) {
                p("downloadSourceImage() makeDir orgSourceImageDirectoryURL error")
            }
            
            let saveImageUrl = orgSourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadOrgSourceImage url : \(file_name)")
            return nil
        }
        
    }
    

}
