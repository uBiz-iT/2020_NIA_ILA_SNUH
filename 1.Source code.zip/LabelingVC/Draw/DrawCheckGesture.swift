//
//  DrawCheckGesture.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 13/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    func setupImageView(){

        canvas.removeFromSuperview()
        
        // canvas 속성 설정 --------
        EditingImage.addSubview(canvas)                                    // canvas를 이미지뷰 안에 추가
        canvas.translatesAutoresizingMaskIntoConstraints = false
        canvas.topAnchor.constraint(equalTo: canvas.superview!.topAnchor).isActive = true
        canvas.bottomAnchor.constraint(equalTo: canvas.superview!.bottomAnchor).isActive = true
        canvas.leadingAnchor.constraint(equalTo: canvas.superview!.leadingAnchor, constant: 0).isActive = true
        canvas.trailingAnchor.constraint(equalTo: canvas.superview!.trailingAnchor, constant: 0).isActive = true
        
        canvas.isClosedCurve = true
        canvas.lineWidth = lineWidth
        
    }
    
    func drawLineLongPress(gesture: UILongPressGestureRecognizer) {
        
        if (WorkingProjectMark != "Y") { return }
        
        if (noticeClearMark && loadedMarkNum > 0) {
            self.view.showToast(toastMessage: "마크 클리어(삭제) 후, 신규 마킹이 가능합니다.", duration: 1.0)
            return
        }
        
        let point = gesture.location(in: EditingImage) // 이미지뷰를 기준으로 위치 획득
        
        switch lineType {
        case LineType.FreeCurve,
             LineType.Eraser,
             LineType.ClosedCurve:
            break
        case LineType.Ellipse,
             LineType.Rectangle:
            //longPressGesture_Ellipse(point: point)
            break
        case LineType.Polygon:
            longPressGesture_Polygon(point: point)
            break
        }
    }
    
    func drawLineTapped(gesture: UITapGestureRecognizer) {
        
        if (WorkingProjectMark != "Y") { return }

        if (noticeClearMark && loadedMarkNum > 0) {
            self.view.showToast(toastMessage: "마크 클리어(삭제) 후, 신규 마킹이 가능합니다.", duration: 1.0)
            return
        }
        

        let point = gesture.location(in: EditingImage) // 이미지뷰를 기준으로 위치 획득
        
        switch lineType {
        case LineType.FreeCurve,
             LineType.Eraser,
             LineType.ClosedCurve:
            break
        case LineType.Ellipse:
            longPressGesture_Ellipse(point: point)
            break
        case LineType.Rectangle:
            longPressGesture_Rectangle(point: point)
            break
        case LineType.Polygon:
            tapGesture_Polygon(point: point)
            break
        }
    }
    
    func drawLineBegan(gesture: UIGestureRecognizer) {
        
        if (WorkingProjectMark != "Y") { return }
        
        p("drawLineBegan() loadedMarkNum : \(loadedMarkNum)")
        
        if (noticeClearMark && loadedMarkNum > 0) {
            self.view.showToast(toastMessage: "마크 클리어(삭제) 후, 신규 마킹이 가능합니다.", duration: 1.0)
            return
        }
        
        let point = gesture.location(in: EditingImage) // 이미지뷰를 기준으로 위치 획득
        
        befFreeCurvePoint = point
        
        switch lineType {
        case LineType.FreeCurve,
             LineType.ClosedCurve:
            panGestureBegan_FreeCurve(point: point)
            break
        case LineType.Eraser:
            panGestureBegan_Eraser(point: point)
            break
        case LineType.Ellipse:
            panGestureBegan_Ellipse(point: point)
            break
        case LineType.Rectangle:
            panGestureBegan_Rectangle(point: point)
            break
        case LineType.Polygon:
            panGestureBegan_Poygon(point: point)
            break
        }
    }
    
    func drawLineMoved(gesture: UIGestureRecognizer) {
        
        let point = gesture.location(in: EditingImage) // 이미지뷰를 기준으로 위치 획득

        guard let befPoint = befFreeCurvePoint else { return }
        befFreeCurvePoint = point

        // 이전 포인트와 현재 포인트의 차이가 크면 갑자기 튀는 현상임.
        let xgap = abs(befPoint.x - point.x)
        let ygap = abs(befPoint.y - point.y)
        if (xgap == 0 && ygap == 0) { return }
        
        switch lineType {
        case LineType.FreeCurve,
             LineType.ClosedCurve:
            panGestureMoved_FreeCurve(point: point)
            break
        case LineType.Eraser:
            panGestureMoved_Eraser(point: point)
            break
        case LineType.Ellipse:
            panGestureMoved_Ellipse(point: point)
            break
        case LineType.Rectangle:
            panGestureMoved_Rectangle(point: point)
            break
        case LineType.Polygon:
            panGestureMoved_Poygon(point: point)
            break
        }

    }
    
    func drawLineEnded(gesture: UIGestureRecognizer) {

        let point = gesture.location(in: EditingImage) // 이미지뷰를 기준으로 위치 획득

        switch lineType {
        case LineType.FreeCurve,
             LineType.ClosedCurve:
            panGestureEnded_FreeCurve(point: point)
            break
        case LineType.Eraser:
            panGestureEnded_Eraser(point: point)
            break
        case LineType.Ellipse,
             LineType.Rectangle:
            break
        case LineType.Polygon:
            break
        }
        
    }

    func drawLineEnded() {
        
        switch lineType {
        case LineType.FreeCurve,
             LineType.Eraser,
             LineType.ClosedCurve:
            break
        case LineType.Ellipse:
            drawEllipseEnded()
            break
        case LineType.Rectangle:
            drawRectangleEnded()
            break
        case LineType.Polygon:
            //drawPolygonEnded()
            break
        }
        
    }
    
    func compareLineBegan(gesture: UIGestureRecognizer) {
        if (OrientationValue == .landscape) {
            return
        }
        else {
            let point = gesture.location(in: regionView)
            compareLinePanPrevPoint = point
            panGestureBegan_CompareLine(point: point)
        }
    }
    
    func compareLineMoved(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: regionView)
        compareLinePanPrevPoint = point
        panGestureMoved_CompareLine(point: point)
    }
    
    func compareLineEnded(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: regionView) // 이미지뷰를 기준으로 위치 획득
        panGestureEnded_CompareLine(point: point)
    }

    func compareLineImageViewBegan(gesture: UIGestureRecognizer) {
        if (OrientationValue == .portrait) {
            return
        }
        else {
            let point = gesture.location(in: imageRegionView)
            compareLinePanPrevPoint = point
            panGestureBegan_CompareLine(point: point)
        }
    }
    
    func compareLineImageViewMoved(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: imageRegionView)
        compareLinePanPrevPoint = point
        panGestureMoved_CompareLine(point: point)
    }
    
    func compareLineImageViewEnded(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: imageRegionView) // 이미지뷰를 기준으로 위치 획득
        panGestureEnded_CompareLine(point: point)
    }

    func compareLineOrgImageViewBegan(gesture: UIGestureRecognizer) {
        if (OrientationValue == .portrait) {
            return
        }
        else {
            let point = gesture.location(in: orgImageRegionView)
            compareLinePanPrevPoint = point
            panGestureBegan_CompareLine(point: point)
        }
    }
    
    func compareLineOrgImageViewMoved(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: orgImageRegionView)
        compareLinePanPrevPoint = point
        panGestureMoved_CompareLine(point: point)
    }
    
    func compareLineOrgImageViewEnded(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: orgImageRegionView) // 이미지뷰를 기준으로 위치 획득
        panGestureEnded_CompareLine(point: point)
    }

}
