//
//  DrawCompareLine.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020/09/24.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func drawCompareLine() {
    
        compareLineLayer.removeFromSuperlayer()
        compareLineLayerOrg.removeFromSuperlayer()
        compareLineControlPoint.removeFromSuperlayer()
        compareLineControlPointOrg.removeFromSuperlayer()

        if (OrientationValue == .landscape) {
            // 시작, 끝 좌표 정의
            let widthCenter = imageRegionView.frame.width / 2
            let height = imageRegionView.frame.height
            
            compareLineApexStart = CGPoint(x: widthCenter, y: 0)
            compareLineApexEnd = CGPoint(x: widthCenter, y: height)

            // 시작, 끝 연결
            let linePath = UIBezierPath()
            linePath.move(to: compareLineApexStart)
            linePath.addLine(to: compareLineApexEnd)
            compareLineLayer.path = linePath.cgPath
            compareLineLayer.strokeColor = UIColor.systemBlue.cgColor
            compareLineLayer.lineWidth = 1
            compareLineLayer.lineJoin = CAShapeLayerLineJoin.round
            imageRegionView.layer.addSublayer(compareLineLayer)
            
            compareLineLayerOrg = compareLineLayer.copyLayer()
            orgImageRegionView.layer.addSublayer(compareLineLayerOrg)

            // 컨트롤 포인트 생성
            let controlPointSize = CGSize(width: 60, height: 60)

            let x = compareLineApexEnd.x - 30
            let y = compareLineApexEnd.y - 120
            
            let fillColor = UIColor(red: controlPointColor.redValue, green: controlPointColor.greenValue, blue: controlPointColor.blueValue, alpha: 0.2)
            compareLineControlPoint.fillColor = fillColor.cgColor
            
            compareLineControlPoint.strokeColor = controlPointColor.cgColor
            compareLineControlPoint.lineWidth = 1
            compareLineControlPoint.path =
                UIBezierPath(ovalIn:CGRect(x: 0, y: 0, width: controlPointSize.width, height: controlPointSize.height)).cgPath
            compareLineControlPoint.frame = CGRect(origin: CGPoint(x:x,y:y), size: controlPointSize)
            imageRegionView.layer.addSublayer(compareLineControlPoint)
            
            compareLineControlPointOrg = compareLineControlPoint.copyLayer()
            orgImageRegionView.layer.addSublayer(compareLineControlPointOrg)
            
        }
        else {
            // 시작, 끝 좌표 정의
            let widthCenter = regionView.frame.width / 2
            let height = regionView.frame.height
            
            compareLineApexStart = CGPoint(x: widthCenter, y: 0)
            compareLineApexEnd = CGPoint(x: widthCenter, y: height)

            // 시작, 끝 연결
            let linePath = UIBezierPath()
            linePath.move(to: compareLineApexStart)
            linePath.addLine(to: compareLineApexEnd)
            compareLineLayer.path = linePath.cgPath
            compareLineLayer.strokeColor = UIColor.systemBlue.cgColor
            compareLineLayer.lineWidth = 1
            compareLineLayer.lineJoin = CAShapeLayerLineJoin.round
            regionView.layer.addSublayer(compareLineLayer)
            
            // 컨트롤 포인트 생성
            let controlPointSize = CGSize(width: 60, height: 60)

            let x = compareLineApexEnd.x - 30
            let y = compareLineApexEnd.y - 120
            
            let fillColor = UIColor(red: controlPointColor.redValue, green: controlPointColor.greenValue, blue: controlPointColor.blueValue, alpha: 0.2)
            compareLineControlPoint.fillColor = fillColor.cgColor
            
            compareLineControlPoint.strokeColor = controlPointColor.cgColor
            compareLineControlPoint.lineWidth = 1
            compareLineControlPoint.path =
                UIBezierPath(ovalIn:CGRect(x: 0, y: 0, width: controlPointSize.width, height: controlPointSize.height)).cgPath
            compareLineControlPoint.frame = CGRect(origin: CGPoint(x:x,y:y), size: controlPointSize)
            regionView.layer.addSublayer(compareLineControlPoint)
        }
    }
    
    func panGestureBegan_CompareLine(point:CGPoint) {

        isCompareLineMoving = false
        isCompareLineMovingOrg = false

        if (OrientationValue == .landscape) {
            if compareLineControlPoint.frame.contains(point) {
                panPrevPoint = point
                isCompareLineMoving = true
            }
            else if compareLineControlPointOrg.frame.contains(point) {
                panPrevPoint = point
                isCompareLineMovingOrg = true
            }
        }
        else {
            if compareLineControlPoint.frame.contains(point) {
                panPrevPoint = point
                isCompareLineMoving = true
            }
        }
    }
    
    func panGestureMoved_CompareLine(point:CGPoint) {

        if (!isCompareLineMoving && !isCompareLineMovingOrg) { return }
        
        if (OrientationValue == .landscape) {
            if (isCompareLineMoving || isCompareLineMovingOrg) {    // 컨트롤포인트 위치가 동시에 같이 움직이므로 한문에 써도 무방. 분리 불필요
                var x = point.x
                var y = point.y
                
                if x < 30 { x = 30 }
                if y < 30 { y = 30 }
                if x > imageRegionView.frame.width - 30 { x = imageRegionView.frame.width - 30 }
                if y > imageRegionView.frame.height - 30 { y = imageRegionView.frame.height - 30 }

                let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
                var newOrigin:CGPoint = CGPoint()
                    
                newOrigin = CGPoint(x:compareLineControlPoint.frame.origin.x + gapPoint.x,
                                    y:compareLineControlPoint.frame.origin.y + gapPoint.y)
                disableAnimation {
                    compareLineControlPoint.frame.origin = newOrigin
                    compareLineControlPointOrg.frame.origin = newOrigin
                }
                
                compareLineLayer.removeFromSuperlayer()
                compareLineLayerOrg.removeFromSuperlayer()

                compareLineApexStart = CGPoint(x: compareLineApexStart.x + gapPoint.x, y: compareLineApexStart.y)
                compareLineApexEnd = CGPoint(x: compareLineApexEnd.x + gapPoint.x, y: compareLineApexEnd.y)

                // 시작, 끝 연결
                let linePath = UIBezierPath()
                linePath.move(to: compareLineApexStart)
                linePath.addLine(to: compareLineApexEnd)
                compareLineLayer.path = linePath.cgPath
                compareLineLayer.strokeColor = UIColor.systemBlue.cgColor
                compareLineLayer.lineWidth = 1
                compareLineLayer.lineJoin = CAShapeLayerLineJoin.round
                imageRegionView.layer.addSublayer(compareLineLayer)
                
                compareLineLayerOrg = compareLineLayer.copyLayer()
                orgImageRegionView.layer.addSublayer(compareLineLayerOrg)
             
                panPrevPoint = CGPoint(x: x, y: y)

            }
        }
        else {
            
            var x = point.x
            var y = point.y
            
            if x < 30 { x = 30 }
            if y < 30 { y = 30 }
            if x > regionView.frame.width - 30 { x = regionView.frame.width - 30 }
            if y > regionView.frame.height - 30 { y = regionView.frame.height - 30 }

            let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
            var newOrigin:CGPoint = CGPoint()
                
            newOrigin = CGPoint(x:compareLineControlPoint.frame.origin.x + gapPoint.x,
                                y:compareLineControlPoint.frame.origin.y + gapPoint.y)
            disableAnimation {
                compareLineControlPoint.frame.origin = newOrigin
            }
            
            compareLineLayer.removeFromSuperlayer()
            compareLineApexStart = CGPoint(x: compareLineApexStart.x + gapPoint.x, y: compareLineApexStart.y)
            compareLineApexEnd = CGPoint(x: compareLineApexEnd.x + gapPoint.x, y: compareLineApexEnd.y)

            // 시작, 끝 연결
            let linePath = UIBezierPath()
            linePath.move(to: compareLineApexStart)
            linePath.addLine(to: compareLineApexEnd)
            compareLineLayer.path = linePath.cgPath
            compareLineLayer.strokeColor = UIColor.systemBlue.cgColor
            compareLineLayer.lineWidth = 1
            compareLineLayer.lineJoin = CAShapeLayerLineJoin.round
            regionView.layer.addSublayer(compareLineLayer)
            
            panPrevPoint = CGPoint(x: x, y: y)
        }
    }
    
    func panGestureEnded_CompareLine(point:CGPoint) {
        isCompareLineMoving = false
    }
    
}
