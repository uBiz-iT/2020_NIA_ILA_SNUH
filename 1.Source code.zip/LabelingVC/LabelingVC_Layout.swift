//
//  LabelingVC_Layout.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 03/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    // --------------------------------------------------------------------------
    // 이미지 상단 컨트롤 레이아웃 수동 지정을 위한 자동 레이아웃 설정 disable
    // --------------------------------------------------------------------------
    func disableAutoresizingMask() {
        lineTypeSegmented.translatesAutoresizingMaskIntoConstraints = false
        clearImageButton.translatesAutoresizingMaskIntoConstraints = false
        undoButton.translatesAutoresizingMaskIntoConstraints = false
        redoButton.translatesAutoresizingMaskIntoConstraints = false
        reloadButton.translatesAutoresizingMaskIntoConstraints = false
        drawCompleteButton.translatesAutoresizingMaskIntoConstraints = false
        lineColorSegmented.translatesAutoresizingMaskIntoConstraints = false
        cutModeSegmented.translatesAutoresizingMaskIntoConstraints = false
        
        regionView.translatesAutoresizingMaskIntoConstraints = false                    // 20200814
        
        imageRegionView.translatesAutoresizingMaskIntoConstraints = false
        orgImageRegionView.translatesAutoresizingMaskIntoConstraints = false             // 20200814
        regionSplitView.translatesAutoresizingMaskIntoConstraints = false

        tableViewLabelLeft.translatesAutoresizingMaskIntoConstraints = false
        tableViewLabelRight.translatesAutoresizingMaskIntoConstraints = false
        thumbnailGroupView.translatesAutoresizingMaskIntoConstraints = false
        collectionViewThumbnail.translatesAutoresizingMaskIntoConstraints = false
        collectionViewBottom.translatesAutoresizingMaskIntoConstraints = false
    }
    
    func drawMenuButtonHidden(hidden:Bool) {
        lineTypeSegmented.isHidden = hidden
        lineColorSegmented.isHidden = hidden
        cutModeSegmented.isHidden = hidden
        clearImageButton.isHidden = hidden
        undoButton.isHidden = hidden
        redoButton.isHidden = hidden
        reloadButton.isHidden = hidden
        drawCompleteButton.isHidden = hidden
        alphaSliderView.isHidden = hidden
        widthSliderView.isHidden = hidden
        markCountLabel.isHidden = hidden
        markCountTitle.isHidden = hidden
    }
    
    func adjustLabelListViewLocation() {
        
        lineTypeSegmentedHeight = 40.0
        lineTypeSegmentedWidth = (OrientationValue == UIInterfaceOrientationMask.portrait) ? 230.0 : 300.0
        lineColorSegmentedWidth = lineTypeSegmentedWidth - 40
        
        //var lineTypeLocationOffset:CGFloat = 111.0

        var lineTypeLocationOffset:CGFloat = 83.0  // 20200814
        //var lineTypeLocationOffset:CGFloat = 123.0

        if (WorkingProjectMulti == "Y" ) {
            collectionViewThumbnail.isHidden = false
            thumbnailGroupView.isHidden = false
            if (WorkingProjectMark == "Y") {
                collectionThumbnailTopConstant = 137
                drawMenuButtonHidden(hidden: false)
            }
            else {
                collectionThumbnailTopConstant = 137
                lineTypeLocationOffset = lineTypeLocationOffset - 47
                drawMenuButtonHidden(hidden: true)
            }
        }
        else {
            collectionViewThumbnail.isHidden = true
            thumbnailGroupView.isHidden = true
            if (WorkingProjectMark == "Y") {
                //collectionThumbnailTopConstant = 15
                collectionThumbnailTopConstant = 55     // 20200817
                drawMenuButtonHidden(hidden: false)
            }
            else {
                //collectionThumbnailTopConstant = -25
                collectionThumbnailTopConstant = 15     // 20200817
                drawMenuButtonHidden(hidden: true)
            }
        }
        
        //-------------------------------------------------------------------------------
        //  썸네일뷰를 가로는 화면 좌측 위치에 아래로 길게 배열, 세로모드일 경우에는 상단 위치에 옆으로 길게 배열
        //-------------------------------------------------------------------------------
        if (OrientationValue == .landscape) {
            
            tableViewLeftLeftConstant = 0
            lineTypeSegmenedTopConstant = collectionThumbnailTopConstant + lineTypeLocationOffset
            if let layout = collectionViewThumbnail.collectionViewLayout as? UICollectionViewFlowLayout {
                layout.scrollDirection = .horizontal
            }

        }
        else {
            tableViewLeftLeftConstant = 0
            lineTypeSegmenedTopConstant = collectionThumbnailTopConstant + lineTypeLocationOffset
            if let layout = collectionViewThumbnail.collectionViewLayout as? UICollectionViewFlowLayout {
                layout.scrollDirection = .horizontal
            }
        }
        
        for constraint in constraints {
            constraint.isActive = false
        }
        constraints.removeAll()
        
        var newConstarint:NSLayoutConstraint?
        
        if (OrientationValue == .landscape) {

            newConstarint = thumbnailGroupView.topAnchor.constraint(equalTo: view.topAnchor, constant: collectionThumbnailTopConstant)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 1)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -1)
            constraints.append(newConstarint!)
            //newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 109)
            newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 79)
            constraints.append(newConstarint!)

        }
        else {
            newConstarint = thumbnailGroupView.topAnchor.constraint(equalTo: view.topAnchor, constant: collectionThumbnailTopConstant)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 1)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -1)
            constraints.append(newConstarint!)
            //newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 109)
            newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 79)
            constraints.append(newConstarint!)
        }
        
        
        newConstarint = lineColorSegmented.topAnchor.constraint(equalTo: view.topAnchor, constant: lineTypeSegmenedTopConstant)
        constraints.append(newConstarint!)
        newConstarint = lineColorSegmented.rightAnchor.constraint(equalTo: view.rightAnchor, constant:-2)
        constraints.append(newConstarint!)
        newConstarint = lineColorSegmented.widthAnchor.constraint(equalToConstant: lineColorSegmentedWidth)
        constraints.append(newConstarint!)
        newConstarint = lineColorSegmented.heightAnchor.constraint(equalToConstant: lineTypeSegmentedHeight)
        constraints.append(newConstarint!)
        
        newConstarint = lineTypeSegmented.topAnchor.constraint(equalTo: lineColorSegmented.topAnchor, constant: 0)
        //newConstarint = lineTypeSegmented.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: topConstant)
        constraints.append(newConstarint!)
        newConstarint = lineTypeSegmented.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 2)
        constraints.append(newConstarint!)
        newConstarint = lineTypeSegmented.widthAnchor.constraint(equalToConstant: lineTypeSegmentedWidth)
        constraints.append(newConstarint!)
        newConstarint = lineTypeSegmented.heightAnchor.constraint(equalTo: lineColorSegmented.heightAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = cutModeSegmented.topAnchor.constraint(equalTo: lineTypeSegmented.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = cutModeSegmented.leftAnchor.constraint(equalTo: lineTypeSegmented.rightAnchor, constant: 5)
        constraints.append(newConstarint!)
        newConstarint = cutModeSegmented.widthAnchor.constraint(equalTo: lineTypeSegmented.widthAnchor, multiplier: 1/CGFloat(lineTypeSegmented.numberOfSegments)*2.0)
        constraints.append(newConstarint!)
        newConstarint = cutModeSegmented.heightAnchor.constraint(equalTo: lineTypeSegmented.heightAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = clearImageButton.topAnchor.constraint(equalTo: lineTypeSegmented.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = clearImageButton.leftAnchor.constraint(equalTo: cutModeSegmented.rightAnchor, constant: 5)
        constraints.append(newConstarint!)
        newConstarint = clearImageButton.widthAnchor.constraint(equalTo: lineTypeSegmented.widthAnchor, multiplier: 1/CGFloat(lineTypeSegmented.numberOfSegments)*1.0)
        constraints.append(newConstarint!)
        newConstarint = clearImageButton.heightAnchor.constraint(equalTo: lineTypeSegmented.heightAnchor, constant: 1)
        constraints.append(newConstarint!)
        
        newConstarint = undoButton.topAnchor.constraint(equalTo: lineTypeSegmented.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = undoButton.leftAnchor.constraint(equalTo: clearImageButton.rightAnchor, constant: -1)
        constraints.append(newConstarint!)
        newConstarint = undoButton.widthAnchor.constraint(equalTo: lineTypeSegmented.widthAnchor, multiplier: 1/CGFloat(lineTypeSegmented.numberOfSegments)*1.0)
        constraints.append(newConstarint!)
        newConstarint = undoButton.heightAnchor.constraint(equalTo: lineTypeSegmented.heightAnchor, constant: 1)
        constraints.append(newConstarint!)
        
        newConstarint = redoButton.topAnchor.constraint(equalTo: lineTypeSegmented.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = redoButton.leftAnchor.constraint(equalTo: undoButton.rightAnchor, constant: -1)
        constraints.append(newConstarint!)
        newConstarint = redoButton.widthAnchor.constraint(equalTo: lineTypeSegmented.widthAnchor, multiplier: 1/CGFloat(lineTypeSegmented.numberOfSegments)*1.0)
        constraints.append(newConstarint!)
        newConstarint = redoButton.heightAnchor.constraint(equalTo: lineTypeSegmented.heightAnchor, constant: 1)
        constraints.append(newConstarint!)
        
        newConstarint = reloadButton.topAnchor.constraint(equalTo: lineTypeSegmented.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = reloadButton.leftAnchor.constraint(equalTo: redoButton.rightAnchor, constant: -1)
        constraints.append(newConstarint!)
        newConstarint = reloadButton.widthAnchor.constraint(equalTo: lineTypeSegmented.widthAnchor, multiplier: 1/CGFloat(lineTypeSegmented.numberOfSegments)*1.0)
        constraints.append(newConstarint!)
        newConstarint = reloadButton.heightAnchor.constraint(equalTo: lineTypeSegmented.heightAnchor, constant: 1)
        constraints.append(newConstarint!)
        
        newConstarint = drawCompleteButton.topAnchor.constraint(equalTo: lineTypeSegmented.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = drawCompleteButton.leftAnchor.constraint(equalTo: reloadButton.rightAnchor, constant:5)
        constraints.append(newConstarint!)
        newConstarint = drawCompleteButton.widthAnchor.constraint(equalTo: lineTypeSegmented.widthAnchor, multiplier: 1/CGFloat(lineTypeSegmented.numberOfSegments)*1.0)
        constraints.append(newConstarint!)
        newConstarint = drawCompleteButton.heightAnchor.constraint(equalTo: lineTypeSegmented.heightAnchor, constant: 1)
        constraints.append(newConstarint!)
        
        newConstarint = tableViewLabelLeft.topAnchor.constraint(equalTo: lineTypeSegmented.bottomAnchor, constant: 5)
        constraints.append(newConstarint!)
        newConstarint = tableViewLabelLeft.leftAnchor.constraint(equalTo: view.leftAnchor, constant: tableViewLeftLeftConstant)
        constraints.append(newConstarint!)
        newConstarint = tableViewLabelLeft.widthAnchor.constraint(equalToConstant: 80)
        constraints.append(newConstarint!)
        newConstarint = tableViewLabelLeft.bottomAnchor.constraint(equalTo: collectionViewMainImage.topAnchor, constant: -10)
        constraints.append(newConstarint!)
        
        newConstarint = tableViewLabelRight.topAnchor.constraint(equalTo: tableViewLabelLeft.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = tableViewLabelRight.rightAnchor.constraint(equalTo: view.rightAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = tableViewLabelRight.widthAnchor.constraint(equalTo: tableViewLabelLeft.widthAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = tableViewLabelRight.bottomAnchor.constraint(equalTo: tableViewLabelLeft.bottomAnchor, constant: 0)
        constraints.append(newConstarint!)
        
        if (LabelList.getLabelCount(location: 1) == 0) {
            tableViewLabelLeft.isHidden = true
            tableViewLabelRight.isHidden = true
            collectionViewBottom.isHidden = false
            
            newConstarint = collectionViewBottom.topAnchor.constraint(equalTo: view.bottomAnchor, constant: -150)
            constraints.append(newConstarint!)
            newConstarint = collectionViewBottom.leftAnchor.constraint(equalTo: view.leftAnchor, constant: tableViewLeftLeftConstant)
            constraints.append(newConstarint!)
            newConstarint = collectionViewBottom.rightAnchor.constraint(equalTo: view.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = collectionViewBottom.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -150 + 64)
            constraints.append(newConstarint!)
            
            newConstarint = regionView.topAnchor.constraint(equalTo: tableViewLabelLeft.topAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = regionView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: tableViewLeftLeftConstant)
            constraints.append(newConstarint!)
            newConstarint = regionView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -1)
            constraints.append(newConstarint!)
            newConstarint = regionView.bottomAnchor.constraint(equalTo: collectionViewBottom.topAnchor, constant: -2)
            constraints.append(newConstarint!)

            if (OrientationValue == .landscape) {
                newConstarint = regionSplitView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = regionSplitView.centerXAnchor.constraint(equalTo: regionView.centerXAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = regionSplitView.widthAnchor.constraint(equalToConstant: 1)
                constraints.append(newConstarint!)
                newConstarint = regionSplitView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
                constraints.append(newConstarint!)

                newConstarint = orgImageRegionView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = orgImageRegionView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = orgImageRegionView.rightAnchor.constraint(equalTo: regionSplitView.leftAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = orgImageRegionView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
                constraints.append(newConstarint!)

                newConstarint = imageRegionView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = imageRegionView.leftAnchor.constraint(equalTo: regionSplitView.rightAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = imageRegionView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = imageRegionView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
                constraints.append(newConstarint!)
            }
            else {
                newConstarint = regionSplitView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = regionSplitView.centerYAnchor.constraint(equalTo: regionView.centerYAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = regionSplitView.heightAnchor.constraint(equalToConstant: 1)
                constraints.append(newConstarint!)
                newConstarint = regionSplitView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
                constraints.append(newConstarint!)

                newConstarint = orgImageRegionView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = orgImageRegionView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = orgImageRegionView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = orgImageRegionView.bottomAnchor.constraint(equalTo: regionSplitView.topAnchor, constant: 0)
                constraints.append(newConstarint!)

                newConstarint = imageRegionView.topAnchor.constraint(equalTo: regionSplitView.bottomAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = imageRegionView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = imageRegionView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
                constraints.append(newConstarint!)
                newConstarint = imageRegionView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
                constraints.append(newConstarint!)
            }

        }
        else {
            tableViewLabelLeft.isHidden = false
            tableViewLabelRight.isHidden = false
            collectionViewBottom.isHidden = true
            
            newConstarint = regionView.topAnchor.constraint(equalTo: tableViewLabelLeft.topAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = regionView.leftAnchor.constraint(equalTo: tableViewLabelLeft.rightAnchor, constant:1)
            constraints.append(newConstarint!)
            newConstarint = regionView.rightAnchor.constraint(equalTo: tableViewLabelRight.leftAnchor, constant: -1)
            constraints.append(newConstarint!)
            newConstarint = regionView.bottomAnchor.constraint(equalTo: tableViewLabelLeft.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)

//            newConstarint = imageRegionView.topAnchor.constraint(equalTo: tableViewLabelLeft.topAnchor, constant: 0)
//            constraints.append(newConstarint!)
//            newConstarint = imageRegionView.leftAnchor.constraint(equalTo: tableViewLabelLeft.rightAnchor, constant:1)
//            constraints.append(newConstarint!)
//            newConstarint = imageRegionView.rightAnchor.constraint(equalTo: tableViewLabelRight.leftAnchor, constant: -1)
//            constraints.append(newConstarint!)
//            newConstarint = imageRegionView.bottomAnchor.constraint(equalTo: tableViewLabelLeft.bottomAnchor, constant: 0)
//            constraints.append(newConstarint!)
            
            newConstarint = collectionViewBottom.topAnchor.constraint(equalTo: view.bottomAnchor, constant: -170)
            constraints.append(newConstarint!)
            newConstarint = collectionViewBottom.leftAnchor.constraint(equalTo: view.leftAnchor, constant: tableViewLeftLeftConstant)
            constraints.append(newConstarint!)
            newConstarint = collectionViewBottom.rightAnchor.constraint(equalTo: view.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = collectionViewBottom.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -170 + 64)
            constraints.append(newConstarint!)
            
        }
        
        for constraint in constraints {
            constraint.isActive = true
        }
        
    }
    
    func clearConstraints(_ constraint:NSLayoutConstraint?) {
        if constraint != nil {
            constraint!.isActive = false
        }
    }
    
}
