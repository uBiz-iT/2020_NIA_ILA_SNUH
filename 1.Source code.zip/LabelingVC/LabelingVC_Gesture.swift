//
//  MainVC_Gesture.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 06/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass


// 더블 탭 인터벌 세팅, 기본 인터벌 값을 적용할 경우 더블탭 시간 체크로 인하여 싱글 탭 이벤트 발생 시간이 좀 오래걸림
class UIShortTapGestureRecognizer: UITapGestureRecognizer {
    
    //anything below 0.3 may cause doubleTap to be inaccessible by many users
    let tapMaxDelay: Double = 0.3 // 0.26 seconds
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesBegan(touches, with: event)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + tapMaxDelay) { [weak self] in
            if self?.state != UIGestureRecognizer.State.recognized {
                self?.state = UIGestureRecognizer.State.failed
            }
        }
    }
}

extension LabelingVC {
    
    func initGesture() {
        
        setScrollViewPropertyForImage()
        setOrgScrollViewPropertyForImage()

        // 20200924
        //compareLineGesture = UIPanGestureRecognizer(target: self, action: #selector(compareLinePanned(_:)))
        compareLineGesture = UILongPressGestureRecognizer(target: self, action: #selector(compareLinePanned(_:)))
        compareLineGesture!.minimumPressDuration = 0.1    // 0.1이 딱 좋음. 더 작게하면 더블탭이 매우 힘듬.
        compareLineGesture!.allowableMovement = 15 // 15 points
        compareLineGesture!.delaysTouchesEnded = true
        compareLineGestureImage = UILongPressGestureRecognizer(target: self, action: #selector(compareLineImagePanned(_:)))
        compareLineGestureImage!.minimumPressDuration = 0.1    // 0.1이 딱 좋음. 더 작게하면 더블탭이 매우 힘듬.
        compareLineGestureImage!.allowableMovement = 15 // 15 points
        compareLineGestureImage!.delaysTouchesEnded = true
        compareLineGestureOrg = UILongPressGestureRecognizer(target: self, action: #selector(compareLineOrgImagePanned(_:)))
        compareLineGestureOrg!.minimumPressDuration = 0.1    // 0.1이 딱 좋음. 더 작게하면 더블탭이 매우 힘듬.
        compareLineGestureOrg!.allowableMovement = 15 // 15 points
        compareLineGestureOrg!.delaysTouchesEnded = true

        // panning
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(imagePanned(_:)))

        // 1 touch 1 tap
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped(_:)))
        tapGesture!.numberOfTouchesRequired = 1
        tapGesture!.numberOfTapsRequired = 1
        
        // 1 touch 2 taps
        doubleTapGesture = UIShortTapGestureRecognizer(target: self, action: #selector(scrollImageDoubleTapped(_:)))
        doubleTapGesture!.numberOfTouchesRequired = 1
        doubleTapGesture!.numberOfTapsRequired = 2
        ScrollImage.addGestureRecognizer(doubleTapGesture!)

        tapGesture!.require(toFail: doubleTapGesture!)  // 더블 탭 fail일 경우 싱글 탭 적용, 이렇게 하지 않으면 싱글 및 더블 탭 모두 이벤트 발생

        // 2 touches 1 tap
        tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(imageTapped2(_:)))
        tapGesture2!.numberOfTouchesRequired = 2
        tapGesture2!.numberOfTapsRequired = 1
        ScrollImage.addGestureRecognizer(tapGesture2!)
        
        tapGesture2Org = UITapGestureRecognizer(target: self, action: #selector(imageTapped2(_:)))
        tapGesture2Org!.numberOfTouchesRequired = 2
        tapGesture2Org!.numberOfTapsRequired = 1
        orgScrollImage.addGestureRecognizer(tapGesture2Org!)
        
        // long press
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(imageLongPressed(_:)))
        longPressGesture!.minimumPressDuration = 0.3
        longPressGesture!.allowableMovement = 15 // 15 points
        longPressGesture!.delaysTouchesBegan = true
        
        // long press : pan 제스처가 지연되는 현상이 발생하므로 대신에 짧은 long press로 대신함
        longPressGestureForNodelayPan = UILongPressGestureRecognizer(target: self, action: #selector(imagePanned(_:)))
        longPressGestureForNodelayPan!.minimumPressDuration = 0.05  // 20200902   0.1에서 0.05로 변경
        longPressGesture!.allowableMovement = 15 // 15 points
        longPressGesture!.delaysTouchesEnded = true

        // 20200821 원본 이미지 뷰쪽에 swipe 처리
        //setupSwipeGestureRecognizer(view:orgImageRegionView, touches:1)
        swipeLeftGestureOrg = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeLeftGestureOrg!.direction = .left
        swipeLeftGestureOrg!.numberOfTouchesRequired = 1

        swipeRightGestureOrg = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeRightGestureOrg!.direction = .right
        swipeRightGestureOrg!.numberOfTouchesRequired = 1


        // 20200902
        swipeLeftGesture = UISwipeGestureRecognizer(target: self, action: #selector(editingImageSwiped(_:)))
        swipeLeftGesture!.direction = .left
        swipeLeftGesture!.numberOfTouchesRequired = 1

        swipeRightGesture = UISwipeGestureRecognizer(target: self, action: #selector(editingImageSwiped(_:)))
        swipeRightGesture!.direction = .right
        swipeRightGesture!.numberOfTouchesRequired = 1


        // 1 touch 2 taps 20200822 원본 이미지 쪽
        doubleTapGestureForOrgImage = UIShortTapGestureRecognizer(target: self, action: #selector(orgScrollImageDoubleTapped(_:)))
        doubleTapGestureForOrgImage!.numberOfTouchesRequired = 1
        doubleTapGestureForOrgImage!.numberOfTapsRequired = 2
        doubleTapGestureForOrgImage!.delaysTouchesEnded = true
        orgImageRegionView.addGestureRecognizer(doubleTapGestureForOrgImage!)

    }
    
    func removeGestureForCompareLine() {

        imageRegionView.removeGestureRecognizer(compareLineGestureImage!)
        orgImageRegionView.removeGestureRecognizer(compareLineGestureOrg!)
        regionView.removeGestureRecognizer(compareLineGesture!)
    }
    
    func addGestureForCompareLine() {

        removeGestureForCompareLine()

        if OrientationValue == .landscape {
            imageRegionView.addGestureRecognizer(compareLineGestureImage!)
            orgImageRegionView.addGestureRecognizer(compareLineGestureOrg!)
        }
        else {
            regionView.addGestureRecognizer(compareLineGesture!)
        }
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage로부터 모든 마킹용 제스처 제거
    //--------------------------------------------------------------------------------
    func removeGestureForMarking() {
        EditingImage.removeGestureRecognizer(panGesture!)
        EditingImage.removeGestureRecognizer(longPressGesture!)
        EditingImage.removeGestureRecognizer(longPressGestureForNodelayPan!)
        EditingImage.removeGestureRecognizer(tapGesture!)
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage 뷰에 마킹용 제스처 설정
    //--------------------------------------------------------------------------------
    func addGestureForMarking(lineType:LineType) {
        
        removeGestureForMarking()
        
        // 20200902 마크 프로젝트가 아닌 경우에는 설정하지 않음
        if (WorkingProjectMark == "N") {
            return
        }
        
        switch lineType {
        case .ClosedCurve, .FreeCurve:
            //EditingImage.addGestureRecognizer(panGesture!)
            EditingImage.addGestureRecognizer(longPressGestureForNodelayPan!)
            break
        case .Eraser:
            EditingImage.addGestureRecognizer(longPressGestureForNodelayPan!)
            break
        case .Ellipse:
            EditingImage.addGestureRecognizer(panGesture!)
            //EditingImage.addGestureRecognizer(longPressGestureForNodelayPan!)  // tap인지 long인지 체크하는 것 때문에 여기서는 사용안하고 그냥 pan 제스처 사용
            EditingImage.addGestureRecognizer(tapGesture!)
            break
        case .Rectangle:
            EditingImage.addGestureRecognizer(panGesture!)
            //EditingImage.addGestureRecognizer(longPressGestureForNodelayPan!)  // tap인지 long인지 체크하는 것 때문에 여기서는 사용안하고 그냥 pan 제스처 사용
            EditingImage.addGestureRecognizer(tapGesture!)
            break
        case .Polygon:
            EditingImage.addGestureRecognizer(panGesture!) // long press 제스처를 사용해야 하므로 longPressGestureForNodelayPan를 사용하지 않고 panGesture를 사용함
            EditingImage.addGestureRecognizer(tapGesture!)
            EditingImage.addGestureRecognizer(longPressGesture!)
            break
        }
    }
    
    //--------------------------------------------------------------------------------
    // 1 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func imageTapped(_ gesture: UITapGestureRecognizer) {
        drawLineTapped(gesture: gesture)
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage 2 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func imageTapped2(_ gesture: UITapGestureRecognizer) {
        ScrollImage.zoomScale = 1
        orgScrollImage.zoomScale = 1
    }
    
    //--------------------------------------------------------------------------------
    // scrollImage 1 touch 2 tap
    //--------------------------------------------------------------------------------
    @objc func scrollImageDoubleTapped(_ gesture: UITapGestureRecognizer) {
        
        //showReferImageScreen().   20200925 막고 아래 추가
        
        let point = gesture.location(in: imageRegionView)
        let quadOfWidth = imageRegionView.frame.width / 4
        
        // 위치가 폭을 기준으로 폭 크기의 4분의 1 좌측이면 맨 처음으로 이동하고
        if point.x < quadOfWidth {
            if (WorkingProjectMulti == "Y") {
                arrowSubImageFirstClick()
            }
            else {
                arrowImageFirstClick()
            }
        }
        // 폭 크기의 4분의 3보다 큰 위치를 탭했으면 맨 우측 이미지로 이동
        else if point.x > (quadOfWidth * 3) {
            if (WorkingProjectMulti == "Y") {
                arrowSubImageLastClick()
            }
            else {
                arrowImageLastClick()
            }
        }
    }

    //--------------------------------------------------------------------------------
    // EditingImage 1 touch long press
    //--------------------------------------------------------------------------------
    @objc func imageLongPressed(_ gesture: UILongPressGestureRecognizer) {
        p("imageLongPressed: ", gesture.state.rawValue)
        switch gesture.state {
        case .began:
            drawLineLongPress(gesture: gesture)
            p("imageLongPressed Began: ", gesture.state.rawValue)
            break
        case .ended, .cancelled, .failed:
            p("imageLongPressed Ended: ", gesture.state.rawValue)
            break
        default:
            p("imageLongPressed etc. : ", gesture.state.rawValue)
            break
        }
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage panning
    //--------------------------------------------------------------------------------
    @objc func imagePanned(_ gesture: UIPanGestureRecognizer) {
        
        struct Temp { static var numberOfTouchesWhenBegan = 0 }
        
        if (gesture.state == .began) {
            Temp.numberOfTouchesWhenBegan = gesture.numberOfTouches
            drawLineBegan(gesture: gesture)
        }
        if (gesture.state == .changed) {
            drawLineMoved(gesture: gesture)
        }
        if (gesture.state == .ended) {
            drawLineEnded(gesture: gesture)
        }
        
    }
    
    //--------------------------------------------------------------------------------
    // 20200924 region view panning
    //--------------------------------------------------------------------------------
    @objc func compareLinePanned(_ gesture: UIPanGestureRecognizer) {
        
        struct Temp { static var numberOfTouchesWhenBegan = 0 }
        
        if (gesture.state == .began) {
            p("compareLinePanned.began")
            Temp.numberOfTouchesWhenBegan = gesture.numberOfTouches
            compareLineBegan(gesture: gesture)
        }
        if (gesture.state == .changed) {
            p("compareLinePanned.changed")
            compareLineMoved(gesture: gesture)
        }
        if (gesture.state == .ended) {
            p("compareLinePanned.ended")
            compareLineEnded(gesture: gesture)
        }
        
    }
    
    @objc func compareLineImagePanned(_ gesture: UIPanGestureRecognizer) {
        
        struct Temp { static var numberOfTouchesWhenBegan = 0 }
        
        if (gesture.state == .began) {
            //p("compareLineImagePanned.began")
            Temp.numberOfTouchesWhenBegan = gesture.numberOfTouches
            compareLineImageViewBegan(gesture: gesture)
        }
        if (gesture.state == .changed) {
            //p("compareLineImagePanned.changed")
            compareLineImageViewMoved(gesture: gesture)
        }
        if (gesture.state == .ended) {
            //p("compareLineImagePanned.ended")
            compareLineImageViewEnded(gesture: gesture)
        }
        
    }
    
    @objc func compareLineOrgImagePanned(_ gesture: UIPanGestureRecognizer) {
        
        struct Temp { static var numberOfTouchesWhenBegan = 0 }
        
        if (gesture.state == .began) {
            p("compareLineOrgImagePanned.began")
            Temp.numberOfTouchesWhenBegan = gesture.numberOfTouches
            compareLineOrgImageViewBegan(gesture: gesture)
        }
        if (gesture.state == .changed) {
            p("compareLineOrgImagePanned.changed")
            compareLineOrgImageViewMoved(gesture: gesture)
        }
        if (gesture.state == .ended) {
            p("compareLineOrgImagePanned.ended")
            compareLineOrgImageViewEnded(gesture: gesture)
        }
        
    }
    
    //--------------------------------------------------------------------------------
    // Swipe Gesture Set
    //--------------------------------------------------------------------------------
    func setupSwipeGestureRecognizer(view:UIView, touches:Int) {
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeLeft.direction = .left
        swipeLeft.numberOfTouchesRequired = touches
        view.addGestureRecognizer(swipeLeft)

        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeRight.direction = .right
        swipeRight.numberOfTouchesRequired = touches
        view.addGestureRecognizer(swipeRight)

        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeUp.direction = .up
        swipeUp.numberOfTouchesRequired = touches
        view.addGestureRecognizer(swipeUp)

        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeDown.direction = .down
        swipeDown.numberOfTouchesRequired = touches
        view.addGestureRecognizer(swipeDown)
    }
    
    func checkSwipeGesture(Mark_YN:String) {
        if (Mark_YN == "N") {
            enableSwipeGesture()
        }
        else {
            disableSwipeGesture()
        }
    }
    
    // 20200902
    func enableSwipeGesture() {
        imageRegionView.addGestureRecognizer(swipeLeftGesture!)
        imageRegionView.addGestureRecognizer(swipeRightGesture!)
        orgImageRegionView.addGestureRecognizer(swipeLeftGestureOrg!)
        orgImageRegionView.addGestureRecognizer(swipeRightGestureOrg!)
    }
    
    // 20200902
    func disableSwipeGesture() {
        imageRegionView.removeGestureRecognizer(swipeLeftGesture!)
        imageRegionView.removeGestureRecognizer(swipeRightGesture!)
        orgImageRegionView.removeGestureRecognizer(swipeLeftGestureOrg!)
        orgImageRegionView.removeGestureRecognizer(swipeRightGestureOrg!)
        p("disableSwipeGesture()")
    }
    
    // 20200902
    @objc func editingImageSwiped(_ gesture: UISwipeGestureRecognizer) -> Void {
        if (WorkingProjectMulti == "Y") {
            if gesture.numberOfTouches == 1 {
                if gesture.direction == UISwipeGestureRecognizer.Direction.right {
                    arrowSubImageLeftClick()
                }
                else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
                    arrowSubImageRightClick()
                }
            }
        }
        else {
            if gesture.numberOfTouches == 1 {
                if gesture.direction == UISwipeGestureRecognizer.Direction.right {
                    arrowLeftClick()
                }
                else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
                    arrowRightClick()
                }
            }
        }
    }
    
    
    @objc func imageSwiped(_ gesture: UISwipeGestureRecognizer) -> Void {
        
        let point = gesture.location(in: regionView)
        
        // swipe가 발생하였는데 컨트롤포인트 위치인 경우에는 swipe 처리하지 않음
        if compareLineControlPoint.frame.contains(point) {
            return
        }
        
        if (WorkingProjectMulti == "Y") {
            if gesture.numberOfTouches == 1 {
                if gesture.direction == UISwipeGestureRecognizer.Direction.right {
                    arrowSubImageLeftClick()
                }
                else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
                    arrowSubImageRightClick()
                }
            }
        }
        else {
            if gesture.numberOfTouches == 1 {
                if gesture.direction == UISwipeGestureRecognizer.Direction.right {
                    arrowLeftClick()
                }
                else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
                    arrowRightClick()
                }
            }
        }
    }
    
    //--------------------------------------------------------------------------------
    // orgScrollImage 1 touch 2 tap
    //--------------------------------------------------------------------------------
    @objc func orgScrollImageDoubleTapped(_ gesture: UITapGestureRecognizer) {
        
        let point = gesture.location(in: orgImageRegionView)        // 20200925 region view로 변경
        let quadOfWidth = orgImageRegionView.frame.width / 4
        
        // 위치가 폭을 기준으로 폭 크기의 4분의 1 좌측이면 맨 처음으로 이동하고
        if point.x < quadOfWidth {
            if (WorkingProjectMulti == "Y") {
                arrowSubImageFirstClick()
            }
            else {
                arrowImageFirstClick()
            }
        }
        // 폭 크기의 4분의 3보다 큰 위치를 탭했으면 맨 우측 이미지로 이동
        else if point.x > (quadOfWidth * 3) {
            if (WorkingProjectMulti == "Y") {
                arrowSubImageLastClick()
            }
            else {
                arrowImageLastClick()
            }
        }

    }


}
