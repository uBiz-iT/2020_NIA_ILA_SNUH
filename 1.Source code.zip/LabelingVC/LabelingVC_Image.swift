//
//  MainVC_Image.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 06/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    //-------------------------------------------------------------------------------------
    // ScrollImage : 이미지의 확대/축소/확대된 이미지 이동 등을 위하여 사용, 이미지를 scroll view 안에서 사용
    //-------------------------------------------------------------------------------------
    func setScrollViewPropertyForImage() {
        ScrollImage.contentSize = EditingImage.bounds.size
        ScrollImage.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        
        ScrollImage.alwaysBounceVertical = false
        ScrollImage.alwaysBounceHorizontal = false
        ScrollImage.showsVerticalScrollIndicator = true
        ScrollImage.flashScrollIndicators()
        
        // 최소 터치수를 최소2개, 최대2개로 설정
        // 싱글터치는 이미지 자체 Pan 이벤트로 사용함.(mark용도로)
        ScrollImage.panGestureRecognizer.minimumNumberOfTouches = 2
        ScrollImage.panGestureRecognizer.maximumNumberOfTouches = 2
        setImageZoomScaleInScrollView()
    }
    
    func setImageZoomScaleInScrollView() {
        let imageViewSize = EditingImage.bounds.size
        let scrollViewSize = ScrollImage.bounds.size
        let widthScale = scrollViewSize.width / imageViewSize.width
        let heightScale = scrollViewSize.height / imageViewSize.height
        
        ScrollImage.minimumZoomScale = min(widthScale, heightScale)
        ScrollImage.maximumZoomScale = ScrollImage.minimumZoomScale * 5.0
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        if (scrollView.tag == 100) {
            return EditingImage
        }
        else if (scrollView.tag == 101) {
            return orgEditingImage
        }
        return EditingImage
    }
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        if (scrollView.tag == 100) {
            widthSliderViewSetNeedsDisplay()
            // 20200925 상대측도 동일하게 zooming
            orgScrollImage.zoomScale = scrollView.zoomScale
            orgScrollImage.contentOffset = scrollView.contentOffset
        }
        else if (scrollView.tag == 101) {                   // 20200925 상대측도 동일하게 zooming
            ScrollImage.zoomScale = scrollView.zoomScale
            ScrollImage.contentOffset = scrollView.contentOffset
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // 20200925 상대측도 동일하게 zooming
        if (scrollView.tag == 100) {
            orgScrollImage.zoomScale = scrollView.zoomScale
            orgScrollImage.contentOffset = scrollView.contentOffset
        }
        else if (scrollView.tag == 101) {
            ScrollImage.zoomScale = scrollView.zoomScale
            ScrollImage.contentOffset = scrollView.contentOffset
        }
    }
    
    func downloadSourceImage(_ imageId:String, _ file_name:String) -> String? {

        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
        if let data = try? Data(contentsOf: url!) {
            
            let f = imageId + ".jpg"
            
            if (!makeDir(fullPath: sourceImageDirectoryURL!.path)) {
                p("downloadSourceImage() makeDir sourceImageDirectoryURL error")
            }
            
            let saveImageUrl = sourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadSourceImage url : \(file_name)")
            return nil
        }
        
    }

    func downloadSourceOrgImage(_ imageId:String, _ file_name:String) -> String? {

        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
        if let data = try? Data(contentsOf: url!) {
            
            let f = "Org_" + imageId + ".jpg"
            
            if (!makeDir(fullPath: sourceImageDirectoryURL!.path)) {
                p("downloadSourceImage() makeDir sourceImageDirectoryURL error")
            }
            
            let saveImageUrl = sourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadSourceImage url : \(file_name)")
            return nil
        }
        
    }

    func downloadMarkedImage(_ imageId:String, _ file_name_url:URL) -> String? {

        let encoded = file_name_url.relativePath.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
        if let data = try? Data(contentsOf: url!) {
            
            let f = file_name_url.lastPathComponent
            if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
                p("downloadMarkedImage() makeDir markedImageDirectoryURL error")
            }
            
            let saveImageUrl = markedImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadMarkedImage url : \(file_name_url.relativePath)")
            return nil
        }
        
    }
    
    func uploadMarkedIndivisualImage(fileURL:URL, imageId:String, serverSourceImagePath:String, serverFileName:String, imageSeq:Int, line:Line?) {
        
        let serverMarkedImageDir = getMarkedImageDirectoryOnServer(serverSourceImagePath: serverSourceImagePath, imageId: imageId)
        var imageInfoToUpload = ImageInfoToUpload()
        imageInfoToUpload.projectCode = WorkingProjectCode
        imageInfoToUpload.projectName = WorkingProjectName
        imageInfoToUpload.imageID = (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id : imageId
        imageInfoToUpload.imageSeq = imageSeq
        imageInfoToUpload.name = serverFileName
        imageInfoToUpload.location = serverMarkedImageDir.relativePath // 상대경로 지정, path로 하면 맨앞에 '/'이 붙어 서버에서 루트로 인식
        imageInfoToUpload.imageFileURL = fileURL
        ImagesToUpload.append(imageInfoToUpload)
        
    }
    
    // ----------------------------------------------------------------------
    // 마킹완료된 이미지 저장하기
    // ----------------------------------------------------------------------
    func saveMarkedImage(imageView:UIImageView, imageId:String) {
        
        // -----------------------------------------------------------------------------------
        // 여기는 전체 이미지 그대로 저장
        // -----------------------------------------------------------------------------------
        var serverFileName = String(format: "%@%@", (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageId, markedImageNameSuffix) // 20200828
        //var serverFileName = String(format: "%@%@%03d", (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageId, markedImageNameSuffix, 0)
        var saveFileName = String(format: "%@.jpg", serverFileName)

        let imageFrame = imageView.frameOfImage
        
        var newImage:UIImage?
        
        if let layerShot = canvas.screenShot(size: ScrollImage.frame.size) {
            let croppedImage = layerShot.crop(rect: imageFrame)
            let resizedImage = croppedImage.resize(scale: imageView.imageScale)
            // 소스 이미지에 canvas 이미지를 오버레이
            newImage = imageView.image?.overlayWith(image: resizedImage!, posX: 0, posY: 0)
        }

        // 마킹이 되었을 경우에는 이미지를 저장해 놓음
        if (WorkingProjectMulti == "Y") {
            subImageArray[selectedSubImageRowNum].newMarking = true
            subImageArray[selectedSubImageRowNum].newMarkedImage = newImage
            subImageArray[selectedSubImageRowNum].mark_num = canvas.lines.count
            collectionViewThumbnail.reloadData()
        }
        else {
            imageArray[currentImageIndex].newMarking = true
            imageArray[currentImageIndex].newMarkedImage = newImage
            imageArray[currentImageIndex].markNum = canvas.lines.count
            collectionViewMainImage.reloadData()
        }
        
        // 20200901 마크가 0이면 return. 기존에 있는거 지우는 것은 json 파일 올릴때(저장 call) 삭제하도록 함(seq 0)
        if canvas.lines.count == 0 {
            return
        }
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
            p("saveMarkedImage() : makeDir markedImageDirectoryURL error")
        }
        
        // 저장할 파일명 URL 정의
        let saveImageURL = markedImageDirectoryURL!.appendingPathComponent(saveFileName)
        
        if (!saveImage(image: newImage!, writeTo: saveImageURL)) {
            p("saveMarkedImage() : saveImage is false.")
        }

        let serverSourceImagePath = imageArray[currentImageIndex].serverLocation!
        p("serverSourceImagePath: \(serverSourceImagePath)")

        // -----------------------------------------------------------------------------------
        // 저장된 파일 URL을 서버 위치에 업로드(원본이미지 + 마크 오버레이), imageSeq는 1부터... json 파일이 0.. 0이면 업로드 프로그램이 삭제 요청을 먼저 하고 진행하게끔 개발했음
        // -----------------------------------------------------------------------------------
        uploadMarkedIndivisualImage(fileURL: saveImageURL, imageId: imageId, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: 1, line: nil)

        // -----------------------------------------------------------------------------------
        // 저장된 파일 URL을 서버 위치에 업로드(마크 전체)
        // -----------------------------------------------------------------------------------
        serverFileName = String(format: "%@%@%03d", (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageId, markedImageNameSuffix, 0)
        saveFileName = String(format: "%@.jpg", serverFileName)
        let savedAllMarkUrl =  saveAllMarkWithoutImage(imageView: imageView, saveFileName: saveFileName, lines: canvas.lines)
        uploadMarkedIndivisualImage(fileURL: savedAllMarkUrl, imageId: imageId, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: 2, line: nil)

        // -----------------------------------------------------------------------------------
        // 여기서부터는 마크 하나하나 개별적으로 저장
        // -----------------------------------------------------------------------------------
        var count = 0
        canvas.lines.forEach { (line) in
            
            count = count + 1
            var markLine = line
            
            markLine.alpha = 1.0
            markLine.fillcolor = markLine.color
            markLine.isClip = false                     // 저장할 경우에는 클립핑영역도 제대로 저장

            // 저장할 이미지 명 만들기
            let serverFileName = String(format: "%@%@%03d",(WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageId, markedImageNameSuffix, count)
            let saveFileName = String(format: "%@.jpg", serverFileName)

            // 이미지 저장후 저장된 파일 URL을 리턴받음
            let savedImageUrl = saveIndivisualCanvas(imageView: imageView, saveFileName: saveFileName, line: markLine)
            
            // 저장된 파일 URL을 서버 위치에 업로드
            uploadMarkedIndivisualImage(fileURL: savedImageUrl, imageId: imageId, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: count + 3, line: markLine) // 20200828 count + 3으로 변경

        }

    }
    
    func saveIndivisualCanvas(imageView:UIImageView, saveFileName:String, line:Line) -> URL {
        
        let indiCanvas = Canvas()
        indiCanvas.frame = canvas.frame
        indiCanvas.isClosedCurve = true
        indiCanvas.lineWidth = lineWidth
        // -----------------------
        
        indiCanvas.backgroundColor = UIColor.black
        
        indiCanvas.lines.append(line)
        
        let imageFrame = imageView.frameOfImage
        print("imageFrame : ", imageFrame)
        
        var resizedImage:UIImage?
        var newImage:UIImage?

        // 원본 이미지의 실제 사이즈 구하기
        let originalImageSize = CGSize(width: imageView.image!.size.width * imageView.image!.scale, height: imageView.image!.size.height * imageView.image!.scale)
        
        if let layerShot = indiCanvas.screenShot(size: ScrollImage.frame.size) {
            let croppedImage = layerShot.crop(rect: imageFrame)
            resizedImage = croppedImage.resize(scale: imageView.imageScale)
            // 빈 이미지에 canvas 이미지를 오버레이
            newImage = getEmptyImage(size: originalImageSize).overlayWith(image: resizedImage!, posX: 0, posY: 0)
        }
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
            p("saveMarkedImage() : makeDir markedImageDirectoryURL error")
        }
        
        // 저장할 파일명 URL 정의
        let saveImageURL = markedImageDirectoryURL!.appendingPathComponent(saveFileName)
        
        if (!saveImage(image: newImage!, writeTo: saveImageURL)) {
            print("saveMarkedImage() saveImage is false.")
        }
        
        return saveImageURL

    }
    
    // --------------------------------------------------------------------------------------
    // 정해진 크기의 이미지를 색상 없이 생성
    // --------------------------------------------------------------------------------------
    func getEmptyImage(size: CGSize) -> UIImage {
        let rect = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        UIColor.clear.setFill()
        UIRectFill(rect)
        let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return image
    }

    func saveAllMarkWithoutImage(imageView:UIImageView, saveFileName:String, lines:[Line]) -> URL {
        
        let indiCanvas = Canvas()
        indiCanvas.frame = canvas.frame
        indiCanvas.isClosedCurve = true
        indiCanvas.lineWidth = lineWidth
        // -----------------------
        
        indiCanvas.backgroundColor = UIColor.black
        
        canvas.lines.forEach { (line) in
            var l = line
            l.alpha = 1.0
            l.fillcolor = l.color
            indiCanvas.lines.append(l)
        }
        

        let imageFrame = imageView.frameOfImage
        print("imageFrame : ", imageFrame)
        
        var resizedImage:UIImage?
        var newImage:UIImage?

        // 원본 이미지의 실제 사이즈 구하기
        let originalImageSize = CGSize(width: imageView.image!.size.width * imageView.image!.scale, height: imageView.image!.size.height * imageView.image!.scale)

        if let layerShot = indiCanvas.screenShot(size: ScrollImage.frame.size) {
            let croppedImage = layerShot.crop(rect: imageFrame)
            resizedImage = croppedImage.resize(scale: imageView.imageScale)
            // 빈 이미지에 canvas 이미지를 오버레이
            newImage = getEmptyImage(size: originalImageSize).overlayWith(image: resizedImage!, posX: 0, posY: 0)
        }
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
            p("saveMarkedImage() : makeDir markedImageDirectoryURL error")
        }
        
        // 저장할 파일명 URL 정의
        let saveImageURL = markedImageDirectoryURL!.appendingPathComponent(saveFileName)
        
        if (!saveImage(image: newImage!, writeTo: saveImageURL)) {
            print("saveMarkedImage() saveImage is false.")
        }
        
        return saveImageURL
        
    }

    // --------------------------------------------------------------------------------------
    // 20200828 Line을 x,y 좌표로
    // --------------------------------------------------------------------------------------
    func getMyPoints(line:Line) -> [MyPoint] {
        
        var myPoints = [MyPoint]()
        line.points.forEach { (p) in
            var myPoint = MyPoint()
            myPoint.x = Int(Float(p.x).rounded())
            myPoint.y = Int(Float(p.y).rounded())
            myPoints.append(myPoint)
        }
        return myPoints
    }
    
    // --------------------------------------------------------------------------------------
    // x,y좌표를 Line에 사용하기 위해
    // --------------------------------------------------------------------------------------
    func setMyPoints(myPoints:[MyPoint]) -> [CGPoint] {
        var cgPoints = [CGPoint]()
        myPoints.forEach { (p) in
            let cgPoint = CGPoint(x: CGFloat(p.x!), y: CGFloat(p.y!))
            cgPoints.append(cgPoint)
        }
        return cgPoints
    }
    
    
    // --------------------------------------------------------------------------------------
    // 직사각형, 타원의 경우 20200828 Line을 x,y 좌표로
    // --------------------------------------------------------------------------------------
    func getMyBoundingBox(line:Line) -> MyBoundingBox {
        
        var myBoundingBox = MyBoundingBox()
        myBoundingBox.x = Float(line.points[0].x)
        myBoundingBox.y = Float(line.points[0].y)
        myBoundingBox.w = Float(line.points[1].x - line.points[0].x)
        myBoundingBox.h = Float(line.points[2].y - line.points[1].y)

        return myBoundingBox
    }
    
    func getRealPoints(screenPoints:[MyPoint]) -> [MyPoint] {
        
        let beforeZoomScale = ScrollImage.zoomScale
        let beforeContentOffset = ScrollImage.contentOffset
        ScrollImage.zoomScale = 1.0
        
        let imageRect = EditingImage.frameOfImage
        let inX = imageRect.origin.x
        let inY = imageRect.origin.y
        let scale = EditingImage.imageScale
        
        var myPoints = [MyPoint]()
        screenPoints.forEach { (p) in
            var myPoint = MyPoint()
            myPoint.x = Int(Float(((Float(p.x!) - Float(inX)) * Float(scale))).rounded())
            myPoint.y = Int(Float(((Float(p.y!) - Float(inY)) * Float(scale))).rounded())
            myPoints.append(myPoint)
        }

        // 원래의 zoom 크기와 offset으로 원복
        ScrollImage.zoomScale = beforeZoomScale
        ScrollImage.contentOffset = beforeContentOffset

        return myPoints
    }

    func getRealPoints(screenPoints:[CGPoint]) -> [CGPoint] {
        
        let beforeZoomScale = ScrollImage.zoomScale
        let beforeContentOffset = ScrollImage.contentOffset
        ScrollImage.zoomScale = 1.0
        
        let imageRect = EditingImage.frameOfImage
        let inX = imageRect.origin.x
        let inY = imageRect.origin.y
        let scale = EditingImage.imageScale
        
        var myPoints = [CGPoint]()
        screenPoints.forEach { (p) in
            var myPoint = CGPoint()
            myPoint.x = CGFloat(((Float(p.x) - Float(inX)) * Float(scale)))
            myPoint.y = CGFloat(((Float(p.y) - Float(inY)) * Float(scale)))
            myPoints.append(myPoint)
        }

        // 원래의 zoom 크기와 offset으로 원복
        ScrollImage.zoomScale = beforeZoomScale
        ScrollImage.contentOffset = beforeContentOffset

        return myPoints
    }

    func getScreenPoints(myPoints:[CGPoint]) -> [CGPoint] {

        let imageRect = EditingImage.frameOfImage
        let inX = imageRect.origin.x
        let inY = imageRect.origin.y
        let scale = EditingImage.imageScale
        
        var screenPoints = [CGPoint]()
        myPoints.forEach { (p) in
            var cgPoint = CGPoint()
            cgPoint.x = (p.x / scale) + inX
            cgPoint.y = (p.y / scale) + inY
            screenPoints.append(cgPoint)
        }
        return screenPoints
    }

}
